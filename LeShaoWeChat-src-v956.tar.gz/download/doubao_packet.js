/*
 * 豆包 TTS 抓包脚本
 *   - Java 层: 自动探测 okhttp3 并 hook newCall / RealWebSocket.send / onReadMessage (若类名保留则输出精确请求)
 *   - Native 层: hook SSL_read / SSL_write, 抓 TLS 解密后的明文 (与 App 用什么框架无关, 最可靠)
 *
 * 用法:
 *   1. 手机运行 frida-server (与 CPU 架构匹配, 如 frida-server-xx.x-android-arm64)
 *   2. 电脑: adb forward tcp:27042 tcp:27042
 *   3. frida -U -f com.larus.nova -l doubao_packet.js
 *      (modify 场景用 -U -n 豆包)
 *   4. 在豆包 App 里触发一次 TTS 合成/播一段语音, 再按 Ctrl+C 结束
 *
 * 日志文件: /sdcard/Download/tts_capture.log  (adb pull /sdcard/Download/tts_capture.log)
 */

var LOG = "/sdcard/Download/tts_capture.log";
var MAX_DUMP = 160;                      // 每帧 native 明文最多输出的字符数

function writeLog(line) {
    try {
        var ts = new Date().toISOString();
        var out = ts + " " + line;
        Java.perform(function () {
            try {
                var FOS = Java.use("java.io.FileOutputStream");
                var F = Java.use("java.io.File");
                var fs = new FOS(F.$new(LOG), true);
                var s = Java.use("java.lang.String").$new(out + "\n");
                fs.write(s.getBytes("UTF-8"));
                fs.close();
            } catch (e) {}
        });
        console.log(out);
    } catch (e) {
        console.log(line);
    }
}

function printable(b) { // b: Array of bytes 0-255
    var sb = "";
    for (var i = 0; i < b.length; i++) {
        var c = b[i];
        sb += (c >= 32 && c < 127) ? String.fromCharCode(c) : ".";
    }
    return sb;
}

function hexOf(b) {
    var sb = "";
    for (var i = 0; i < b.length; i++) {
        var h = b[i].toString(16);
        sb += (h.length < 2 ? "0" : "") + h;
    }
    return sb;
}

/* ============ 1. Native SSL hook ============ */
function hookSSL() {
    var need = false;
    var libs = ["libssl.so", "libboringssl.so"];
    var targets = [];
    libs.forEach(function (lib) {
        var m = Process.findModuleByName(lib);
        if (!m) return;
        ["SSL_read", "SSL_write"].forEach(function (sym) {
            var p = Module.findExportByName(lib, sym);
            if (p) targets.push([lib + "!" + sym, p]);
        });
    });
    if (!targets.length) {
        ["SSL_read", "SSL_write"].forEach(function (sym) {
            var p = Module.findExportByName(null, sym);
            if (p) targets.push([sym, p]);
        });
    }
    if (!targets.length) {
        writeLog("[native] SSL_read/SSL_write not found, 可能需要落盘到 libboringssl.so 的其它符号, 反馈给我");
        return;
    }
    targets.forEach(function (t) {
        var name = t[0], addr = t[1];
        try {
            Interceptor.attach(addr, {
                onEnter: function (a) {
                    this.writing = name.indexOf("SSL_write") >= 0;
                    if (!this.writing) return;
                    var buf = bufReg(a); var len = lenReg(a);
                    if (buf.isNull() || len <= 0) return;
                    this.dat = Memory.readByteArray(buf, Math.min(len, MAX_DUMP));
                },
                onLeave: function (ret) {
                    var n = ret.toInt32();
                    if (n <= 0) return;
                    if (!this.writing) {
                        var ctx = this.context;
                        var buf = bufReg(ctx); var len = lenReg(ctx);
                        if (buf.isNull() || len <= 0) return;
                        var cap = Math.min(len, MAX_DUMP);
                        var b = Array.prototype.slice.call(new Uint8Array(Memory.readByteArray(buf, cap)));
                        logFrame("R", b, len);
                    } else {
                        if (!this.dat) return;
                        var b = Array.prototype.slice.call(new Uint8Array(this.dat));
                        logFrame("W", b, this.dat_len || n);
                    }
                }
            });
            writeLog("[native] hooked " + name);
        } catch (e) {
            writeLog("[native] fail " + name + " " + e);
        }
    });
}

function bufReg(c) {
    if (c.x1  !== undefined) return c.x1;   // arm64
    if (c.r1  !== undefined) return c.r1;   // arm
    if (c.rsi !== undefined) return c.rsi;  // x86_64
    return null;
}
function lenReg(c) {
    if (c.x2  !== undefined) return c.x2;
    if (c.r2  !== undefined) return c.r2;
    if (c.rdx !== undefined) return c.rdx;
    return 0;
}

var lastN = 0;
function logFrame(dir, bytes, total) {
    var ascii = printable(bytes);
    var hex = hexOf(bytes);
    var line = "[net " + dir + "] len=" + total + " ascii=" + ascii + " hex=" + hex;
    if (dir === "W") line = "[net " + dir + "] len=" + total + " ascii=" + ascii + " hex=" + hex;
    // 只记录含 URL/协议关键字的帧, 降低噪音 (可注释掉改为全部记录)
    if (dir === "W" || /(htt|tts|speech|volc|byte|wss|ws|text|voice|audio|nova|GET|POST|auth|token|/).test(ascii)) {
        if (++lastN <= 500) writeLog(line);
    }
}

/* ============ 2. Java okhttp 探测 ============ */
function hookOkhttp() {
    Java.perform(function () {
        var hit = 0;
        Java.enumerateLoadedClasses({
            onMatch: function (name) {
                if (name.indexOf("okhttp3") < 0) return;
                try {
                    if (name.indexOf("OkHttpClient") >= 0) {
                        Java.use(name).newCall.overloads.forEach(function (o) {
                            o.implementation = function (req) {
                                try {
                                    writeLog("[okhttp] newCall " + req.url() + "\n  headers=" + req.headers() +
                                        "\n  method=" + req.method() + " body=" + (req.body() ? req.body().contentLength() : "-"));
                                } catch (e) { writeLog("[okhttp] newCall? " + e); }
                                return o.call(this, req);
                            };
                        });
                        hit++;
                    }
                    if (name.indexOf("RealWebSocket") >= 0) {
                        Java.use(name).send.overloads.forEach(function (o) {
                            o.implementation = function (m) {
                                writeLog("[okhttp] ws.send " + m);
                                return o.call(this, m);
                            };
                        });
                        Java.use(name).onReadMessage.overloads.forEach(function (o) {
                            o.implementation = function (m) {
                                writeLog("[okhttp] ws.recv " + m);
                                return o.call(this, m);
                            };
                        });
                        hit++;
                    }
                } catch (e) {}
            },
            onComplete: function () {
                writeLog("[okhttp] hooks applied=" + hit + " (0=类名被混淆, 走 native 明文)");
            }
        });
    });
}

Java.perform(function () {
    writeLog("=== doubao_packet starf ===");
    hookSSL();
    hookOkhttp();
});