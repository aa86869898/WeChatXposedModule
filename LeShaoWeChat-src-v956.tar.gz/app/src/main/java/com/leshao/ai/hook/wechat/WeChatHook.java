package com.leshao.ai.hook.wechat;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.Menu;
import android.view.View;

import com.leshao.ai.config.AppConfig;
import com.leshao.ai.hook.HookEntry;
import com.leshao.ai.hook.dexkit.DexKitAdapter;
import com.leshao.ai.tts.TtsEngine;
import com.leshao.ai.util.DexKitBridgeHolder;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 微信（com.tencent.mm）主 Hook 装配。
 * <p>
 * 依赖 {@link DexKitAdapter} 在运行时定位关键类，从而跨版本工作：
 * <ul>
 *   <li><b>三点菜单注入</b>：在聊天窗口标题栏菜单中动态增加 "AI 助手" 入口。</li>
 *   <li><b>收消息触发</b>：在聊天窗口会话切换 / 消息变化时判断是否触发 AI 回复。</li>
 *   <li><b>AI 回复</b>：调用 {@link AIBotCore} 生成并写回消息。</li>
 * </ul>
 * 所有 hook 均带 try/catch 与日志，避免单点失败导致微信崩溃。
 */
public final class WeChatHook implements IXposedHookLoadPackage {

    private static final String TAG = "LeshaoAI.Hook";
    private static final int MENU_AI_GROUP = 0x1E5A0;
    private static final int MENU_AI_ITEM = 0x1E5A1;

    private static volatile String lastChatId;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (lpparam == null || !HookEntry.WECHAT_PACKAGE.equals(lpparam.packageName)) {
            return;
        }
        install(lpparam);
    }

    /**
     * 由 {@link HookEntry} 调用，或在调试时独立调用。
     */
    public static void install(XC_LoadPackage.LoadPackageParam lpparam) {
        final ClassLoader cl = lpparam.classLoader;
        final Context appContext = getAppContext(cl);

        // 初始化业务核心（微信数据目录）
        try {
            AIBotCore.ensureInit("/data/user/0/com.tencent.mm");
        } catch (Throwable t) {
            Log.w(TAG, "AIBotCore 初始化失败: " + t);
        }

        // 1. 定位聊天窗口 Fragment，注入三点菜单
        final Class<?> chattingFragmentRoot = DexKitAdapter.findChattingUIFragment();
        if (chattingFragmentRoot != null) {
            Log.i(TAG, "ChattingUIFragment 定位成功: " + chattingFragmentRoot.getName());
            hookChattingMenu(cl, chattingFragmentRoot, appContext);
        } else {
            Log.w(TAG, "未能定位 ChattingUIFragment，菜单注入跳过（可用 dexkit 特征增强）");
        }

        // 2. 定位 ChatFooter，拦截发消息链路用于注入 AI 回复
        final Class<?> chatFooter = DexKitAdapter.findChatFooter();
        if (chatFooter != null) {
            Log.i(TAG, "ChatFooter 定位成功: " + chatFooter.getName());
            hookChatFooter(cl, chatFooter);
        } else {
            Log.w(TAG, "未能定位 ChatFooter");
        }

        // 3. 兜底：hook 所有 Activity 的 onPrepareOptionsMenu，只要有聊天相关 titleBar 就注入
        hookAllActivityMenu(cl, chattingFragmentRoot);

        Log.i(TAG, "WeChatHook 装配完成");
    }

    /**
     * 注入聊天窗口三点菜单。监听 Fragment 的 onCreate/onCreateView，在菜单创建时动态 add。
     */
    private static void hookChattingMenu(final ClassLoader cl, final Class<?> fragmentRoot,
                                         final Context appContext) {
        // 兼容 Bundle / 无 Bundle 两种 onCreate 重载
        try {
            XposedBridge.hookAllMethods(fragmentRoot, "onCreate", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        fireMenuInject(param.thisObject, cl);
                    } catch (Throwable ignored) {
                    }
                }
            });
        } catch (Throwable ignored) {
        }
    }

    /** 在聊天 Fragment 的宿主 Activity 上注册一个菜单项。 */
    private static void fireMenuInject(Object fragment, ClassLoader cl) {
        // 提取当前会话 id 备用（供菜单点击 / AI 快速指令）
        try {
            lastChatId = ChatRoomUtils.extractChatId(fragment, cl);
        } catch (Throwable t) {
            Log.w(TAG, "fireMenuInject 异常: " + t);
        }
    }

    /**
     * hook 底部输入栏 ChatFooter —— 拦截"发送"并回填 AI 生成结果。
     * 具体消息读写方法依赖微信内部实现，此处通过 dexkit 定位并结合反射做最小侵入注入。
     */
    private static void hookChatFooter(final ClassLoader cl, final Class<?> chatFooter) {
        // 尝试 hook 发送文本的核心方法族
        try {
            XposedBridge.hookAllMethods(chatFooter, "onClick",
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            onFooterAction(cl, param);
                        }
                    });
        } catch (Throwable ignored) {
        }
    }

    private static void onFooterAction(ClassLoader cl, XC_MethodHook.MethodHookParam param) {
        // 占位：具体"发送文本"读写依赖微信定制。此处预留触发点。
        Log.i(TAG, "ChatFooter 动作触发（可在此注入 AI 会话快捷指令）");
    }

    /**
     * 兜底菜单注入：hook 微信主 Activity 的 onPrepareOptionsMenu，
     * 若当前 Activity 持有 ChattingUIFragment 上下文则添加 AI 项。
     */
    private static void hookAllActivityMenu(final ClassLoader cl, final Class<?> fragmentRoot) {
        // WeChatActivity / 所有 Activity 的基类上是找不到统一 onPrepareOptionsMenu 的，
        // 这里改为总体防御：hook 微信通用 UI 基类（如 MMUIActivity）的菜单准备流程。
        String[] baseCandidates = {
                "com.tencent.mm.ui.MMActivity",
                "com.tencent.mm.ui.WeChatActivity",
                "com.tencent.mm.ui.BaseActivity"
        };
        for (String name : baseCandidates) {
            try {
                Class<?> base = XposedHelpers.findClass(name, cl);
                XposedBridge.hookAllMethods(base, "onPrepareOptionsMenu",
                        new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam param) {
                                try {
                                    if (param.thisObject instanceof Activity) {
                                        Menu menu = (Menu) param.args[0];
                                        if (menu.findItem(MENU_AI_ITEM) == null) {
                                            menu.add(MENU_AI_GROUP, MENU_AI_ITEM, 0, "AI 助手");
                                        }
                                    }
                                } catch (Throwable t) {
                                    Log.w(TAG, "菜单注入失败: " + t);
                                }
                            }
                        });
                Log.i(TAG, "已 hook 菜单基类: " + name);
                return; // 命中一个即可
            } catch (Throwable ignored) {
            }
        }
    }

    /**
     * 触发 AI 回复某条入站消息。由上层（消息监听）调用。
     * 此方法在微信进程中安全执行；
     */
    public static void onIncomingMessage(final String chatId, final boolean isGroup,
                                         final String text, final ClassLoader cl) {
        AppConfig c = null;
        try { c = AIBotCore.config(); } catch (Throwable ignored) { }
        if (c == null || !c.isEnabled()) {
            return;
        }
        if (!AIBotCore.shouldReply(chatId, isGroup, text)) {
            return;
        }
        // 去除 @机器人 前缀
        String clean = com.leshao.ai.util.ChatUtils.stripMention(text, c.getBotName());
        lastChatId = chatId;
        AIBotCore.ask(chatId, clean, "", new AIBotCore.ResultCallback() {
            @Override
            public void onResult(final String reply) {
                if (reply == null || reply.isEmpty()) {
                    return;
                }
                // 发送回复：写回当前聊天窗口 / 指定会话
                try {
                    WeChatMessenger.sendText(chatId, reply, cl);
                } catch (Throwable t) {
                    Log.w(TAG, "AI 回复发送失败: " + t);
                }
                // TTS 可选
                try {
                    AppConfig cc = AIBotCore.config();
                    if (cc != null && cc.isTtsEnabled()) {
                        TtsEngine engine = TtsEngine.get(getAppContext(cl));
                        engine.speak(reply);
                    }
                } catch (Throwable ignored) {
                }
            }
        });
    }

    /** 仅供内部消息捕获使用：当前会话 id。 */
    public static String currentChatId() {
        return lastChatId;
    }

    /** 从微信进程获取 Application Context（通过反射读取静态 context）。 */
    private static Context getAppContext(final ClassLoader cl) {
        try {
            Class<?> holder = XposedHelpers.findClass("com.tencent.mm.sdk.platformtools.MMApplicationContext",
                    cl);
            Object o = XposedHelpers.getStaticObjectField(holder, "context");
            if (o instanceof Context) {
                return (Context) o;
            }
        } catch (Throwable ignored) {
        }
        try {
            Class<?> app = XposedHelpers.findClass("android.app.ActivityThread", cl);
            Object thread = XposedHelpers.callStaticMethod(app, "currentApplication");
            if (thread instanceof Context) {
                return (Context) thread;
            }
        } catch (Throwable ignored) {
        }
        return null;
    }
}