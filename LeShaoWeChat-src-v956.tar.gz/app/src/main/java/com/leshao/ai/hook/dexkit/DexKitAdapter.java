package com.leshao.ai.hook.dexkit;

import android.util.Log;

import com.leshao.ai.hook.HookEntry;
import com.leshao.ai.util.DexKitBridgeHolder;

import org.luckypray.dexkit.DexKitBridge;
import org.luckypray.dexkit.query.BatchFindClassUsingStrings;
import org.luckypray.dexkit.query.FindClass;
import org.luckypray.dexkit.query.FindMethod;
import org.luckypray.dexkit.query.enums.StringMatchType;
import org.luckypray.dexkit.query.matchers.ClassMatcher;
import org.luckypray.dexkit.query.matchers.MethodMatcher;
import org.luckypray.dexkit.result.ClassData;
import org.luckypray.dexkit.result.ClassDataList;
import org.luckypray.dexkit.result.MethodData;
import org.luckypray.dexkit.result.MethodDataList;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

/**
 * 微信（com.tencent.mm）跨版本运行时适配核心。
 * <p>
 * 微信 8.x 类名/方法名混淆严重，但 <b>包名与稳定字符串</b>（如日志 TAG {@code MicroMsg.ChattingUIFragment}）
 * 相对稳定。本类以 dexkit 在微信进程内按字符串批量搜索关键类，避免硬编码易漂移的混淆类名。
 * 每个定位器在失败时返回 null 并记录日志，供上层安全降级。
 */
public final class DexKitAdapter {

    private static final String TAG = "LeshaoAI.Adapter";

    /** 聊天窗口日志前缀（稳定字符串锚点）。 */
    private static final String STR_CHATTING_UI = "MicroMsg.ChattingUIFragment";
    private static final String STR_CHATTING_LIFECYCLE = "MicroMsg.ChattingLifecycleObserver";
    private static final String STR_CHAT_FOOTER = "MicroMsg.ChatFooter";

    private DexKitAdapter() {
    }

    /**
     * 定位聊天窗口主 Fragment（com.tencent.mm.ui.chatting.ChattingUIFragment 系列）。
     * 注入"三点菜单 / AI 助手"入口的宿主。
     */
    public static Class<?> findChattingUIFragment() {
        ClassDataList list = classByStrings(
                Collections.singleton("com.tencent.mm.ui.chatting"),
                Collections.singletonList(STR_CHATTING_UI),
                "ChattingUIFragment"
        );
        if (list.isEmpty()) {
            // 更宽的回退：整库按生命周期观察者日志定位
            list = classByStrings(null,
                    Collections.singletonList(STR_CHATTING_LIFECYCLE),
                    "ChattingLifecycle");
        }
        ClassData data = resolveSingle(list, "ChattingUIFragment");
        return toClass(data, "ChattingUIFragment");
    }

    /**
     * 定位底部输入栏（com.tencent.mm.pluginsdk.ui.chat.ChatFooter）。
     * 类名在 8.0.x 未混淆，是拦截/注入发消息的宿主。
     */
    public static Class<?> findChatFooter() {
        ClassDataList list = classByStrings(
                Collections.singleton("com.tencent.mm.pluginsdk.ui.chat"),
                Collections.singletonList(STR_CHAT_FOOTER),
                "ChatFooter"
        );
        if (list.isEmpty()) {
            // 按包名 + 类名特征兜底
            list = classByPackageAndName(
                    "com.tencent.mm.pluginsdk.ui.chat",
                    "ChatFooter",
                    "ChatFooterByName"
            );
        }
        ClassData data = resolveSingle(list, "ChatFooter");
        return toClass(data, "ChatFooter");
    }

    /**
     * 定位 ChatFooter 中真正"发送文本消息"的方法。
     * 通过方法特征（无参数 + 含发送相关字符串/调用）在宿主类内二次过滤。
     *
     * @param footerClass 来自 {@link #findChatFooter()} 的类
     */
    public static Method findSendTextMethod(Class<?> footerClass) {
        if (footerClass == null) {
            Log.w(TAG, "findSendTextMethod: footerClass 为 null");
            return null;
        }
        ClassData host = getClassDataOf(footerClass);
        if (host == null) {
            Log.w(TAG, "findSendTextMethod: 无法取得 ClassData");
            return null;
        }
        try {
            MethodDataList list = host.findMethod(buildFindMethod());
            if (list.isEmpty()) {
                Log.w(TAG, "findSendTextMethod: 未匹配到方法");
                return null;
            }
            MethodData md = list.get(0);
            return md.getMethodInstance(HookEntry.appClassLoader);
        } catch (Throwable t) {
            Log.w(TAG, "findSendTextMethod 失败: " + t);
            return null;
        }
    }

    private static FindMethod buildFindMethod() {
        return FindMethod.create().matcher(MethodMatcher.create()
                .paramCount(0)
                .usingStrings(Collections.singletonList("MicroMsg.ChatFooter"), StringMatchType.Contains));
    }

    /** 按包名 + 稳定字符串批量搜索类。 */
    private static ClassDataList classByStrings(Collection<String> packages,
                                                Collection<String> strings,
                                                String label) {
        DexKitBridge bridge = DexKitBridgeHolder.get();
        if (bridge == null) {
            Log.w(TAG, label + ": DEXKIT 不可用");
            return new ClassDataList();
        }
        try {
            BatchFindClassUsingStrings query = BatchFindClassUsingStrings.create();
            if (packages != null && !packages.isEmpty()) {
                query.searchPackages(packages);
            }
            for (String s : strings) {
                query.addSearchGroup(label + "_" + s,
                        Collections.singletonList(s), StringMatchType.Contains, false);
            }
            java.util.Map<String, ClassDataList> result = bridge.batchFindClassUsingStrings(query);
            ClassDataList merged = new ClassDataList();
            for (ClassDataList list : result.values()) {
                merged.addAll(list);
            }
            return merged;
        } catch (Throwable t) {
            Log.w(TAG, "classByStrings(" + label + ") 失败: " + t);
            return new ClassDataList();
        }
    }

    /** 按包名 + 类名精确匹配搜索。 */
    private static ClassDataList classByPackageAndName(String pkg, String simpleName, String label) {
        DexKitBridge bridge = DexKitBridgeHolder.get();
        if (bridge == null) {
            return new ClassDataList();
        }
        try {
            ClassDataList list = bridge.findClass(
                    FindClass.create()
                            .searchPackages(pkg)
                            .matcher(ClassMatcher.create().className(simpleName, StringMatchType.Equals)));
            return list == null ? new ClassDataList() : list;
        } catch (Throwable t) {
            Log.w(TAG, "classByPackageAndName(" + label + ") 失败: " + t);
            return new ClassDataList();
        }
    }

    /** 取唯一的 ClassData（多结果取第一个并告警）。 */
    private static ClassData resolveSingle(ClassDataList list, String label) {
        if (list == null || list.isEmpty()) {
            Log.w(TAG, label + " 未找到匹配类");
            return null;
        }
        if (list.size() > 1) {
            Log.i(TAG, label + " 命中 " + list.size() + " 个类，取第一个");
        }
        return list.get(0);
    }

    /** ClassData -> Class（失败 null）。 */
    private static Class<?> toClass(ClassData data, String label) {
        if (data == null) {
            return null;
        }
        try {
            return data.getInstance(HookEntry.appClassLoader);
        } catch (Throwable t) {
            Log.w(TAG, label + " getInstance 失败: " + t);
            return null;
        }
    }

    /** 由已加载的 Class 反查 ClassData。 */
    private static ClassData getClassDataOf(Class<?> clazz) {
        DexKitBridge bridge = DexKitBridgeHolder.get();
        if (bridge == null) {
            return null;
        }
        try {
            return bridge.getClassData(clazz);
        } catch (Throwable t) {
            Log.w(TAG, "getClassDataOf(" + clazz.getName() + ") 失败: " + t);
            return null;
        }
    }

    /** 转 Method[]（供 hook 遍历）。 */
    public static Method[] toMethods(MethodDataList list) {
        if (list == null || list.isEmpty()) {
            return new Method[0];
        }
        List<Method> out = new ArrayList<>();
        for (MethodData md : list) {
            try {
                out.add(md.getMethodInstance(HookEntry.appClassLoader));
            } catch (Throwable ignored) {
            }
        }
        return out.toArray(new Method[0]);
    }
}