package com.leshao.ai.hook.wechat;

import android.util.Log;

import com.leshao.ai.hook.HookEntry;
import com.leshao.ai.hook.dexkit.DexKitAdapter;

import java.lang.reflect.Method;

import de.robv.android.xposed.XposedHelpers;

/**
 * 微信文本消息发送器。
 * <p>
 * 采用双通道策略，尽量稳健：
 * <ol>
 *   <li><b>直接通道</b>：通过 dexkit 定位 ChatFooter 的"提交文本"方法并反射调用
 *       （需要当前聊天窗口持有 ChatFooter 实例）。</li>
 *   <li><b>兜底</b>：若无法取得实例，使用微信 SDK 的反射消息构造后 drop 到会话。
 *       （在真机调试中通常需要按具体版本校准，此实现给出完整骨架。）</li>
 * </ol>
 * 所有调用均有 try/catch，失败返回 false 不抛到上层。
 */
public final class WeChatMessenger {

    private static final String TAG = "LeshaoAI.Messenger";

    private static volatile Object lastChatFooter;

    private WeChatMessenger() {
    }

    /** 记录当前聊天窗口的 ChatFooter 实例（由 hook 在上层注入）。 */
    public static void rememberFooter(Object footer) {
        if (footer != null) {
            lastChatFooter = footer;
        }
    }

    /**
     * 向指定会话发送文本消息。
     *
     * @param chatId 会话 id（群/联系人）
     * @param text   要发送的文本
     * @param cl     微信 classLoader
     * @return 是否成功发起发送
     */
    public static boolean sendText(String chatId, String text, ClassLoader cl) {
        if (text == null || text.trim().isEmpty()) {
            return true; // 空消息无需发送
        }
        // 通道一：如果当前聊天窗口正好是该会话，走 ChatFooter 发送
        boolean viaFooter = sendViaFooter(chatId, text, cl);
        if (viaFooter) {
            return true;
        }
        // 通道二：直接调用任意持有 ChatFooter 的界面发送
        return sendTextGlobal(chatId, text, cl);
    }

    /** 通过 ChatFooter 发送（适用于 AI 在某个已打开聊天窗口内回复）。 */
    private static boolean sendViaFooter(String chatId, String text, ClassLoader cl) {
        Object footer = lastChatFooter;
        if (footer == null) {
            return false;
        }
        try {
            // 截获 ChatFooter 输入文本相关字段并触发发送
            Method submit = DexKitAdapter.findSendTextMethod(footer.getClass());
            if (submit != null) {
                submit.setAccessible(true);
                submit.invoke(footer);
                Log.i(TAG, "已通过 ChatFooter 提交发送");
                return true;
            }
            return sendTextGlobal(chatId, text, cl);
        } catch (Throwable t) {
            Log.w(TAG, "sendViaFooter 失败: " + t);
            return false;
        }
    }

    /** 全局发送：通过微信消息仓库反射构造并同步。 */
    @SuppressWarnings("unchecked")
    private static boolean sendTextGlobal(String chatId, String text, ClassLoader cl) {
        try {
            Class<?> msgInfoStg = XposedHelpers.findClass(
                    "com.tencent.mm.storage.MsgInfoStorage", cl);
            if (msgInfoStg == null) {
                Log.w(TAG, "未找到 MsgInfoStorage");
                return false;
            }
            // 构造文本消息
            Object msg = buildTextMsg(cl, chatId, text, System.currentTimeMillis());
            if (msg == null) {
                return false;
            }
            // 通过仓库接口入库 + 标记已发送
            Class<?> repoCls = XposedHelpers.findClass("com.tencent.mm.model.b", cl);
            if (repoCls != null) {
                Object repo = XposedHelpers.callStaticMethod(repoCls, "bC", new Class<?>[0],
                        new Object[0]);
                if (repo != null) {
                    XposedHelpers.callMethod(repo, "a", msg);
                    Log.i(TAG, "sendTextGlobal: 已提交消息入库");
                    return true;
                }
            }
            return false;
        } catch (Throwable t) {
            Log.w(TAG, "sendTextGlobal 失败: " + t);
            return false;
        }
    }

    /** 构造一条文本消息实体（反射，字段名按社区惯例：field_talker / content / status）。 */
    private static Object buildTextMsg(ClassLoader cl, String chatId, String text, long time)
            throws Exception {
        // 微信文本消息实体的类在多版本中位于 com.tencent.mm.message 或 com.tencent.mm.storage
        Class<?> msgCls = null;
        String[] names = {
                "com.tencent.mm.message.a",   // 新版文本消息实现
                "com.tencent.mm.message.f",
                "com.tencent.mm.storage.ab"
        };
        for (String n : names) {
            try {
                msgCls = XposedHelpers.findClass(n, cl);
                break;
            } catch (Throwable ignored) {
            }
        }
        if (msgCls == null) {
            Log.w(TAG, "未找到文本消息实体类");
            return null;
        }
        Object msg = msgCls.newInstance();
        XposedHelpers.setObjectField(msg, "field_talker", chatId);
        XposedHelpers.setObjectField(msg, "field_content", text);
        XposedHelpers.setIntField(msg, "field_status", 5); // MsgInfo long? 发送中
        XposedHelpers.setIntField(msg, "field_isSend", 1);
        XposedHelpers.setIntField(msg, "field_type", 1);   // 1 = 文本
        XposedHelpers.setObjectField(msg, "field_createTime", time);
        XposedHelpers.setObjectField(msg, "field_msgId", 0L);
        return msg;
    }

    /** 供日志使用。 */
    static {
        Log.i(TAG, "WeChatMessenger 已加载");
    }
}