package com.leshao.ai.ui.activity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.leshao.v3.R;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * 白名单管理页（简单 ListView + EditText + 添加按钮）。
 *
 * <p>维护 @触发回复的允许名单：仅名单内的名称才会被当作提及命中。
 * 名单以 JSON 数组形式持久化到 {files}/leshao_ai/whitelist.json。</p>
 *
 * <p>纯 View + XML 实现，不依赖任何第三方库。</p>
 */
public class WhitelistActivity extends Activity {

    private static final String DEFAULT_WHITELIST_FILE = "leshao_ai/whitelist.json";

    private EditText editAddName;
    private Button btnAdd;
    private ListView listWhitelist;
    private TextView textEmpty;

    private final List<String> items = new ArrayList<>();
    private ArrayAdapter<String> adapter;

    private File whitelistFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_whitelist);

        // 白名单存在宿主 data 目录下
        whitelistFile = new File(getFilesDir().getParent(), DEFAULT_WHITELIST_FILE);

        editAddName = findViewById(R.id.edit_add_name);
        btnAdd = findViewById(R.id.btn_add);
        listWhitelist = findViewById(R.id.list_whitelist);
        textEmpty = findViewById(R.id.text_empty);

        adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_list_item_1, items);
        listWhitelist.setAdapter(adapter);

        load();

        // 添加按钮
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addCurrentInput();
            }
        });

        // 键盘“完成”也触发添加
        editAddName.setOnEditorActionListener(new android.widget.TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(android.widget.TextView v, int actionId,
                                          android.view.KeyEvent event) {
                if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE) {
                    addCurrentInput();
                    return true;
                }
                return false;
            }
        });

        // 点击条目从白名单移除
        listWhitelist.setOnItemClickListener((parent, view, position, id) -> {
            items.remove(position);
            notifyChanged();
        });

        // 输入变化时更新按钮可用性
        editAddName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {
            }

            @Override
            public void onTextChanged(CharSequence s, int st, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                btnAdd.setEnabled(!TextUtils.isEmpty(s.toString().trim()));
            }
        });
    }

    private void addCurrentInput() {
        String name = editAddName.getText() == null ? "" : editAddName.getText().toString().trim();
        if (TextUtils.isEmpty(name)) {
            Toast.makeText(this, R.string.whitelist_add_empty_toast, Toast.LENGTH_SHORT).show();
            return;
        }
        if (items.contains(name)) {
            // 已存在则忽略
            editAddName.setText("");
            return;
        }
        items.add(name);
        editAddName.setText("");
        notifyChanged();
    }

    private void notifyChanged() {
        adapter.notifyDataSetChanged();
        boolean empty = items.isEmpty();
        textEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
        listWhitelist.setVisibility(empty ? View.INVISIBLE : View.VISIBLE);
    }

    // ---------- 持久化 ----------

    private void load() {
        items.clear();
        if (whitelistFile.exists()) {
            try {
                byte[] data;
                try (FileInputStream in = new FileInputStream(whitelistFile)) {
                    data = new byte[(int) whitelistFile.length()];
                    int read = in.read(data);
                    if (read <= 0) {
                        data = new byte[0];
                    }
                }
                if (data.length > 0) {
                    JSONArray arr = new JSONArray(new String(data, StandardCharsets.UTF_8));
                    for (int i = 0; i < arr.length(); i++) {
                        items.add(arr.optString(i, ""));
                    }
                }
            } catch (IOException | JSONException e) {
                // 解析失败则视为空名单
            }
        }
        // 过滤空串
        items.removeIf(TextUtils::isEmpty);
        notifyChanged();
    }

    private void save() {
        JSONArray arr = new JSONArray();
        try {
            for (String s : items) {
                arr.put(s);
            }
            File parent = whitelistFile.getParentFile();
            if (parent != null && !parent.exists()) {
                //noinspection ResultOfMethodCallIgnored
                parent.mkdirs();
            }
            try (FileOutputStream out = new FileOutputStream(whitelistFile, false)) {
                out.write(arr.toString().getBytes(StandardCharsets.UTF_8));
            }
        } catch (IOException e) {
            Toast.makeText(this, R.string.whitelist_save_failed_toast, Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(this, R.string.whitelist_saved_toast, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        save();
        super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // 离开页面时持久化
        save();
    }
}
