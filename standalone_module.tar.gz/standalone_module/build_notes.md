# 打包说明与升级兼容

## 1. 打包
- compileOnly 'de.robv.android.xposed:api:82'（LSPosed）
- minSdk 26+, targetSdk 任意
- assets/xposed_init 放入口类
- 无需其它三方依赖（JSON 用 Android 自带 org.json）

## 2. 豆包升级了会不会影响？
分三档风险：

【基本不受影响】(一般不变)
- HTTP 桥协议：127.0.0.1:58911、/voices /synthesize 参数与 WAV 返回
- SpeakerVoice 字段(id/name/styleId/preview)、AudioPreview.previewAudio
- 合成链路入口 TtsClientManager.d 的调用方式（TTS 入口稳定）

【小版本升级可能变】(需要小改)
- 混淆类名：TtsClientManager 的方法名 f/k/d、z.b 回调
- 音色列表接口 network.c.a 的签名/响应JSON字段
- 对策：Hook 点集中在 DoubaoBridgeCore 顶部，升级后看 Logcat
        里 "hookXxx fail" 日志，按报错改类名/方法名即可

【大版本/换架构可能变】(需重定位)
- flow_audio SDK 协议、包名重构（概率低）
- 对策：锁版本（关闭豆包自动更新）+ 升级后跑一遍自测清单

## 3. 升级后自测清单
1) /health 返回 ok
2) 进豆包音色设置后 /voices 有数据
3) /synthesize 能返回 WAV
4) /play 能出声
哪一步失败，看 Logcat(DoubaoBridge) 对应 hook 失败原因。

## 4. 容错设计
- 每个 Hook 独立 try/catch：某 Hook 失效只丢对应功能，不影响豆包本身
- 音色列表抓不到时，可用 /setVoice 切一次音色也能拿到至少1个
