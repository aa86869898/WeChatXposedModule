# INTEGRATION.md — 接入你现有微信模块 详细指南

> 目标：把"豆包音色"接进你已经适配好的微信模块，让微信侧可以用豆包音色合成音频/播报/发语音。
> 前提：你已有微信 Xposed 模块工程（AS + Gradle），并已能正常 Hook 微信。

---

## 0.5 四步速览（照着做，详细见第 1~5 节）

| 步骤 | 做什么 | 文档位置 |
|---|---|---|
| 1 | 把 src/ 下 4 个 java 放进你的模块工程（包名可改，xposed_init 同步改） | 第1节 |
| 2 | assets/xposed_init 增加一行: com.yourmod.doubao.HookEntry | 1.2 节 |
| 3 | 你现有微信入口 handleLoadPackage 开头加包名保护: if (!"com.tencent.mm".equals(lp.packageName)) return; | 第2节 ★必做 |
| 4 | LSPosed 作用域勾选: 微信 ✓ + 豆包(com.larus.nova) ✓；在你现成 TTS/发语音触发点调 WeChatAdapter.doubaoTts(text, voiceId) | 第3、4节 |

## 0. 总览

```
┌──────────────── 你的模块(一个APK) ────────────────┐
│   LSPosed 作用域:  com.tencent.mm ✓  com.larus.nova ✓  │
│                                                    │
│   豆包进程(com.larus.nova)                           │
│     HookEntry ──► DoubaoBridgeCore                  │
│                     ├ Hook音色列表/TTS/音频回调        │
│                     └ HTTP服务 127.0.0.1:58911      │
│                                                    │
│   微信进程(com.tencent.mm)                           │
│     你现有模块(已适配) ──► WeChatAdapter.doubaoTts()   │
│       拿到 WAV → 播放/转silk/发语音                   │
└────────────────────────────────────────────────────┘
```

**文件清单**（standalone_module/src/ 下）
| 文件 | 作用 | 放哪 |
|---|---|---|
| HookEntry.java | 入口，按包名分流 | 你的模块工程，或并入现有入口 |
| DoubaoBridgeCore.java | 豆包桥核心（只在豆包进程跑） | 同上 |
| WeChatAdapter.java | 微信侧 HTTP 调用（拿 WAV） | 同上 |
| DexLocator.java（可选）| DexKit 动态定位，升级自适应 | 同上，见第8节 |

---

## 1. 工程配置

### 1.1 依赖（build.gradle）
```gradle
dependencies {
    compileOnly 'de.robv.android.xposed:api:82'                 // LSPosed API
    // 可选：DexKit 动态适配（第8节）
    implementation 'io.github.LSPosed:DexKit:1.1.8'
}
repositories {
    mavenCentral()
}
```

### 1.2 assets/xposed_init
文件内容追加一行（保持你的旧入口在最前）：
```
你的旧入口类（原有）
com.yourmod.doubao.HookEntry
```

### 1.3 包名
`com.yourmod.doubao` 是占位包名。你可以：
- 保留它（新建同名包放进去）；或
- 改包名（改 3 个 java 的 package + xposed_init 对应行）。

---

## 2. 入口分流（★ 必做，防止豆包崩溃）

你的**现有入口** handleLoadPackage 开头必须有包名保护，例如：
```java
public void handleLoadPackage(final LoadPackageParam lp) {
    if (!"com.tencent.mm".equals(lp.packageName)) return;   // ← 确保有这行
    // ... 你原有微信逻辑
}
```
> 原因：LSPosed 作用域勾选豆包后，你的模块所有入口都会在豆包进程执行。
> 没有包名保护 = 微信 Hook 在豆包进程找微信类 = 崩溃。
> 我给的 HookEntry 已自带保护（只在豆包起桥，微信里不做事），但**你自己的入口也必须保护**。

---

## 3. LSPosed 作用域配置

1. LSPosed → 模块 → 你的模块 → 作用域：
   - ☑ com.tencent.mm（原有，保留）
   - ☑ com.larus.nova（新增）
2. 重启系统生效（或至少重启豆包）。

---

## 4. 微信侧调用（把豆包接进你现成功能）

### 4.1 合成 WAV（核心）
```java
byte[] wav = WeChatAdapter.doubaoTts("你好", "zh_female_wenroutaozi_uranus_bigtts");
if (wav != null && wav.length > 100) {
    // wav 是标准 WAV 音频
}
```

### 4.2 三种用法
| 用途 | 代码 |
|---|---|
| A. 本地播放（播报）| MediaPlayer 播放 wav 字节/文件 |
| B. 存文件 | 写 /sdcard/Download/xxx.wav |
| C. 发微信语音 | 转 silk/amr 后走你现有"发语音"流程 |

### 4.3 拿音色列表（让用户选音色）
```java
String json = WeChatAdapter.doubaoVoices();
// json: [{"id":"..","name":"温柔桃子（升级版）","styleId":"zh_female_wenroutaozi_uranus_bigtts","previewUrl":"..","isUgc":false}]
// 取 styleId 作为 voiceId 传给 doubaoTts
```

### 4.4 触发本地播报（不需要拿音频）
```java
boolean ok = WeChatAdapter.doubaoPlay("你好", "zh_female_wenroutaozi_uranus_bigtts");
```

### 4.5 接入建议
如果你模块里有"TTS 引擎"抽象，把实现指向 doubaoTts 即可；
如果没有，直接在你要发语音/播报的触发点调用 4.1。

---

## 5. 首次使用流程

1. 打开豆包，进【音色设置】翻一遍 tab（灌满音色列表）；
2. 保持豆包后台存活（系统电池设置：豆包=不限制；最近任务锁定）；
3. 微信侧触发你的入口 → 调用 doubaoTts；
4. 观察 Logcat 标签 `DoubaoBridge` 和 `WeChatAdapter`。

---

## 6. 排错清单

| 现象 | 原因 | 处理 |
|---|---|---|
| doubaoTts 返回 null | 豆包桥没起来 | 打开豆包，确认 Logcat 有 `DoubaoBridge: http bridge on 58911` |
| 返回 500/JSON 错误 | 豆包进程被冻结 | 电池白名单 + 保持前台 |
| voices 为空 [] | 没进音色设置 | 进豆包【音色设置】后重试 |
| 微信侧用不了 | 入口没包名保护/作用域没勾豆包 | 看第2、3节 |
| 合成没声音/没音频 | 豆包未登录/Bot 未就绪 | 先正常和豆包对话一次 |

---

## 7. 自测清单（升级豆包后必跑）
1. /health 返回 ok
2. /voices 有数据
3. /synthesize 返回 WAV
4. /play 出声
哪步失败看 Logcat `DoubaoBridge` 里对应 hook fail。

---
（第 8 节 DexKit 动态适配见本文件末尾）

---

## 8. 升级兼容 & DexKit 动态适配（★推荐）

### 8.1 为什么需要
豆包升级后，混淆类/方法名可能变（`network.c`、`TtsClientManager.f/k/d`、`z.b`）。
硬编码方案会失效；DexKit 可以在**运行时扫描 dex**，用"类里用了哪些字符串"定位类/方法，
从而对升级自适应——字符串比类名稳定得多。

### 8.2 原理
DexKit 就是 LSPilot 底层那套定位引擎（find_class / using_strings）。
你给它一组"字符串指纹"，它返回命中类/方法：
- 类指纹：`batchFindClassesUsingStrings({"TtsClientManager", "updateChatBotVoice", "startByText replace"})` → 找到 TtsClientManager
- 方法指纹：`findMethodUsingString("[TTS] start by message")` → 找到 startByText 那个 d() 方法

### 8.3 接入
1) build.gradle 加：`implementation 'io.github.LSPosed:DexKit:1.1.8'`
2) 把 `src/DexLocator.java` 放进工程
3) 启动时（豆包进程）初始化：
```java
// DoubaoBridgeCore.start() 里加一行：
DexLocator.init(lp.appContext.getApplicationInfo().sourceDir);
```
4) 用 DexLocator 替换硬编码 Hook（示例）：
```java
public static Class<?> findTtsManager(ClassLoader cl) throws Exception {
    Class<?> c = DexLocator.findClassByStrings(cl, new HashSet<>(Arrays.asList(
        "TtsClientManager", "updateChatBotVoice", "speaker_style_id")));
    return c != null ? c : Class.forName("com.larus.audio.ttsV2.TtsClientManager", false, cl);
}
```

### 8.4 推荐策略：优先硬编码，失败自动降级 DexKit
```java
Class<?> mgr = null;
try {
    mgr = Class.forName("com.larus.audio.ttsV2.TtsClientManager", false, cl); // 先硬编码
} catch (Throwable t) {
    mgr = DexLocator.findClassByStrings(cl, TTS_MARKERS);                     // 升级降级
}
```

### 8.5 DexKit 常用字符串指纹（豆包 v 已验证）
| 目标 | 常用字符串 |
|---|---|
| TtsClientManager | "TtsClientManager"、"updateChatBotVoice"、"startByText replace" |
| 音色列表解析 network.c | "/alice/user_voice/list"、"BizResponse" |
| startByText 方法 d | "[TTS] start by message"、"start_read_message_reason" |
| 切换音色方法 f | "updateChatBotVoice"、"speaker_style_id" |
| 音频回调 z.b | "didReceiveTTSEvent"、"audio chunkSize" |

> 提示：豆包再升级后如果这些字符串也没了（极小概率换协议），
> 用 LSPilot 工具重新搜一次新字符串指纹即可（本项目就是这么挖出来的）。

### 8.6 完整自测流程（升级后）
1. 看 Logcat `DoubaoBridge` 有没有 `hook fail`；
2. 有 fail → 用 DexKit 定位（或 LSPilot 重新分析）→ 更新指纹/硬编码；
3. 跑第 7 节四项自测。

---

## 9. 风险与合规提示
- 本方案使用你自己的豆包账号做云端合成，请勿商用、勿高频调用；
- 微信"发语音"请走微信原生发送链路（silk 格式注入），避免构造假消息被风控；
- 豆包升级/账号封禁风险由使用者评估。

