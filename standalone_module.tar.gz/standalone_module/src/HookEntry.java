package com.yourmod.doubao;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

/**
 * 入口：一个模块，两个作用域。
 * LSPosed 里给本模块勾选: com.larus.nova + com.tencent.mm
 */
public class HookEntry implements IXposedHookLoadPackage {

    public static final String DOUBAO = "com.larus.nova";
    public static final String WECHAT = "com.tencent.mm";

    @Override
    public void handleLoadPackage(final LoadPackageParam lp) {
        if (DOUBAO.equals(lp.packageName)) {
            // 豆包进程：启动音色桥（Hook + HTTP 服务 127.0.0.1:58911）
            DoubaoBridgeCore.start(lp.classLoader, lp.appContext);
        } else if (WECHAT.equals(lp.packageName)) {
            // 微信进程：你现有模块逻辑
            // 需要时在任意触发点调用:
            //   byte[] wav = WeChatAdapter.doubaoTts(text, voiceId);
            // 然后把 wav 转 silk / 走你现有的发语音流程
        }
    }
}
