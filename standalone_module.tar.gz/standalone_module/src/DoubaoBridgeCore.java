package com.yourmod.doubao;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * 豆包桥核心：在豆包进程内运行。
 * 1) Hook 音色列表接口 + 音色切换，收集全部音色
 * 2) Hook TTS 音频回调 z.b(byte[],boolean) 抓合成音频
 * 3) 起 HTTP 服务 127.0.0.1:58911，供微信侧调用
 */
public class DoubaoBridgeCore {
    private static final String TAG = "DoubaoBridge";
    private static final int PORT = 58911;

    private static ClassLoader CL;
    private static Context CTX;

    public static final Map<String, JSONObject> VOICE_MAP = new ConcurrentHashMap<>();
    public static final Map<String, Object> VOICE_OBJ_MAP = new ConcurrentHashMap<>();
    public static final ConcurrentLinkedQueue<String> REQUEST_LOG = new ConcurrentLinkedQueue<>();

    private static final ByteArrayOutputStream AUDIO = new ByteArrayOutputStream();
    private static final AtomicBoolean CAPTURE = new AtomicBoolean(false);
    private static volatile int SAMPLE_RATE = 24000;
    private static volatile Class<?> MGR_CLS;

    // ================== 启动 ==================
    public static void start(ClassLoader cl, Context ctx) {
        CL = cl;
        CTX = ctx;
        Log.i(TAG, "=== DoubaoBridge loaded ===");
        safe(() -> hookVoiceList());
        safe(() -> hookTts());
        safe(() -> hookAudioCallback());
        new Thread(DoubaoBridgeCore::runServer).start();
        Log.i(TAG, "DoubaoBridge started, port " + PORT);
    }

    private static void safe(Runnable r) {
        try { r.run(); } catch (Throwable t) { Log.i(TAG, "hook fail " + t); }
    }

    // ================== Hook 音色列表 ==================
    private static void hookVoiceList() throws Exception {
        Class<?> netC = Class.forName("com.larus.kmp.voice_setting.voice.network.c", false, CL);
        Class<?> ea9e = Class.forName("ea9.e", false, CL);
        Class<?> nbcD = Class.forName("nbc.d", false, CL);
        Method m = XposedHelpers.findMethodExact(netC, "a", ea9e, nbcD);
        XposedBridge.hookMethod(m, new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                try {
                    Object resp = p.args[0];
                    String body = (String) XposedHelpers.getObjectField(resp, "d");
                    if (body == null || body.isEmpty()) return;
                    parseVoiceList(new JSONObject(body).opt("data"));
                } catch (Throwable t) { Log.i(TAG, "list hook err " + t); }
            }
        });
        Log.i(TAG, "voice list hooked");
    }

    private static void parseVoiceList(Object data) {
        try {
            JSONArray arr = null;
            if (data instanceof JSONObject) {
                JSONObject jo = (JSONObject) data;
                if (jo.has("ugcVoiceList")) arr = jo.optJSONArray("ugcVoiceList");
                else if (jo.has("list")) arr = jo.optJSONArray("list");
                else if (jo.has("voiceList")) arr = jo.optJSONArray("voiceList");
            } else if (data instanceof JSONArray) {
                arr = (JSONArray) data;
            }
            if (arr == null) return;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject v = arr.getJSONObject(i);
                String styleId = v.optString("styleId");
                if (styleId == null || styleId.isEmpty()) continue;
                JSONObject prev = v.optJSONObject("preview");
                String prevUrl = prev == null ? "" : prev.optString("previewAudio");
                JSONObject jo = new JSONObject();
                jo.put("id", v.optString("id"));
                jo.put("name", v.optString("name"));
                jo.put("styleId", styleId);
                jo.put("language", v.optString("languageCode"));
                jo.put("previewUrl", prevUrl);
                jo.put("isUgc", v.optBoolean("isUgcVoice"));
                VOICE_MAP.put(styleId, jo);
                String id = v.optString("id");
                if (id != null && !id.isEmpty()) VOICE_MAP.put(id, jo);
            }
            saveVoices();
            Log.i(TAG, "voices now " + VOICE_MAP.size());
        } catch (Throwable t) { Log.i(TAG, "parseVoiceList err " + t); }
    }

    private static void addVoiceObj(Object sv) {
        if (sv == null) return;
        try {
            String styleId = (String) XposedHelpers.getObjectField(sv, "styleId");
            if (styleId == null || styleId.isEmpty()) return;
            String id = (String) XposedHelpers.getObjectField(sv, "id");
            Object prev = XposedHelpers.getObjectField(sv, "preview");
            String prevUrl = prev == null ? "" : String.valueOf(XposedHelpers.getObjectField(prev, "previewAudio"));
            JSONObject jo = new JSONObject();
            jo.put("id", id == null ? "" : id);
            jo.put("name", String.valueOf(XposedHelpers.getObjectField(sv, "name")));
            jo.put("styleId", styleId);
            jo.put("language", String.valueOf(XposedHelpers.getObjectField(sv, "languageCode")));
            jo.put("previewUrl", prevUrl);
            jo.put("isUgc", (Boolean) XposedHelpers.getObjectField(sv, "isUgcVoice"));
            VOICE_MAP.put(styleId, jo);
            if (id != null && !id.isEmpty()) VOICE_MAP.put(id, jo);
            VOICE_OBJ_MAP.put(styleId, sv);
            if (id != null && !id.isEmpty()) VOICE_OBJ_MAP.put(id, sv);
        } catch (Throwable t) { Log.i(TAG, "addVoiceObj err " + t); }
    }

    private static void saveVoices() {
        try {
            JSONArray arr = new JSONArray();
            HashSet<String> seen = new HashSet<>();
            for (JSONObject v : VOICE_MAP.values()) {
                String k = v.optString("styleId");
                if (k == null || k.isEmpty() || seen.contains(k)) continue;
                seen.add(k); arr.put(v);
            }
            if (CTX != null) {
                File d = new File(CTX.getFilesDir(), "voice_bridge");
                d.mkdirs();
                FileOutputStream fos = new FileOutputStream(new File(d, "voices.json"));
                fos.write(arr.toString(2).getBytes("UTF-8")); fos.close();
            }
            try {
                File pub = new File(Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS), "voice_bridge");
                pub.mkdirs();
                FileOutputStream fos2 = new FileOutputStream(new File(pub, "doubao_voices.json"));
                fos2.write(arr.toString(2).getBytes("UTF-8")); fos2.close();
            } catch (Throwable ignored) {}
        } catch (Throwable t) { Log.i(TAG, "saveVoices err " + t); }
    }

    // ================== Hook TTS ==================
    private static void hookTts() throws Exception {
        MGR_CLS = Class.forName("com.larus.audio.ttsV2.TtsClientManager", false, CL);
        Class<?> speakerVoice = Class.forName("com.larus.im.bean.bot.SpeakerVoice", false, CL);
        Class<?> botModel = Class.forName("com.larus.im.bean.bot.BotModel", false, CL);
        Class<?> c58i = Class.forName("c58.i", false, CL);
        Class<?> cacheCfg = Class.forName("com.larus.audio.bean.CacheConfig", false, CL);

        safe(() -> {
            Method fm = XposedHelpers.findMethodExact(MGR_CLS, "f", speakerVoice);
            XposedBridge.hookMethod(fm, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    addVoiceObj(p.args[0]); saveVoices();
                }
            });
        });
        safe(() -> {
            Method km = XposedHelpers.findMethodExact(MGR_CLS, "k", botModel);
            XposedBridge.hookMethod(km, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        Object bm = p.args[0];
                        if (bm != null) {
                            Object vt = XposedHelpers.callMethod(bm, "getVoiceType");
                            if (vt != null) { addVoiceObj(vt); saveVoices(); }
                        }
                    } catch (Throwable ignored) {}
                }
            });
        });
        safe(() -> {
            Method dm = XposedHelpers.findMethodExact(MGR_CLS, "d",
                    String.class, String.class, String.class, boolean.class,
                    c58i, String.class, cacheCfg, boolean.class, boolean.class,
                    String.class, String.class, Map.class);
            XposedBridge.hookMethod(dm, new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    REQUEST_LOG.offer("startByText " + p.args[2]);
                    Log.i(TAG, "[TTS] " + p.args[2]);
                }
            });
        });
        Log.i(TAG, "tts hooks ready");
    }

    // ================== Hook 音频回调 z.b ==================
    private static void hookAudioCallback() throws Exception {
        Class<?> z = Class.forName("com.larus.audio.ttsV2.z", false, CL);
        Method bm = XposedHelpers.findMethodExact(z, "b", byte[].class, boolean.class);
        XposedBridge.hookMethod(bm, new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                if (!CAPTURE.get()) return;
                byte[] d0 = (byte[]) p.args[0];
                if (d0 != null && d0.length > 0) {
                    synchronized (AUDIO) { AUDIO.write(d0, 0, d0.length); }
                }
            }
        });
        Log.i(TAG, "audio callback hooked");
    }

    // ================== 触发合成 ==================
    private static String resolveStyleId(String voiceId) {
        JSONObject v = VOICE_MAP.get(voiceId);
        if (v != null) {
            String s = v.optString("styleId");
            if (s != null && !s.isEmpty()) return s;
        }
        return voiceId;
    }

    private static boolean triggerTts(String text, String styleId) {
        try {
            Object mgr = XposedHelpers.getStaticObjectField(MGR_CLS, "a");
            if (mgr == null) { Log.i(TAG, "TtsClientManager null"); return false; }
            String convId = (String) XposedHelpers.getStaticObjectField(MGR_CLS, "c");
            Object bot = XposedHelpers.getStaticObjectField(MGR_CLS, "b");
            String botId = "";
            try { botId = bot == null ? "" : String.valueOf(XposedHelpers.callMethod(bot, "getBotId")); } catch (Throwable ignored) {}
            JSONObject v = VOICE_MAP.get(styleId);
            String name = v == null ? "" : v.optString("name");
            Class<?> iCls = Class.forName("c58.i", false, CL);
            Object info = iCls.getDeclaredConstructor(String.class, String.class, String.class, String.class, String.class, int.class)
                    .newInstance(styleId, name, styleId, "", "", 0);
            Map<String, Object> ext = new HashMap<>();
            if (botId != null && !botId.isEmpty()) ext.put("bot_id", botId);
            Object cc = null;
            try {
                cc = Class.forName("com.larus.audio.bean.CacheConfig", false, CL)
                        .getDeclaredConstructor().newInstance();
            } catch (Throwable ignored) {}
            Log.i(TAG, "trigger: " + text + " / " + styleId + " / conv=" + convId);
            XposedHelpers.callMethod(mgr, "d",
                    "bridge_" + System.currentTimeMillis(), convId, text, true,
                    info, "", cc, false, true, "", "voice_bridge", ext);
            return true;
        } catch (Throwable t) { Log.i(TAG, "triggerTts err " + t); return false; }
    }

    private static byte[] buildWav(int rate, byte[] pcm) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(out);
        dos.writeBytes("RIFF"); dos.writeInt(36 + pcm.length); dos.writeBytes("WAVE");
        dos.writeBytes("fmt "); dos.writeInt(16); dos.writeShort(1); dos.writeShort(1);
        dos.writeInt(rate); dos.writeInt(rate * 2); dos.writeShort(2); dos.writeShort(16);
        dos.writeBytes("data"); dos.writeInt(pcm.length); dos.write(pcm); dos.flush();
        return out.toByteArray();
    }

    private static byte[] doSynthesize(String text, String voiceId) {
        String styleId = resolveStyleId(voiceId);
        if (styleId == null || styleId.isEmpty()) { Log.i(TAG, "no voice " + voiceId); return null; }
        synchronized (AUDIO) { AUDIO.reset(); }
        CAPTURE.set(true);
        boolean ok = triggerTts(text, styleId);
        if (!ok) { CAPTURE.set(false); return null; }
        boolean gotFirst = false;
        int lastSize = 0, stableMs = 0;
        long t0 = System.currentTimeMillis();
        while (System.currentTimeMillis() - t0 < 12000) {
            try { Thread.sleep(200); } catch (InterruptedException ignored) {}
            int sz;
            synchronized (AUDIO) { sz = AUDIO.size(); }
            if (sz > 0) gotFirst = true;
            if (gotFirst) {
                if (sz == lastSize) stableMs += 200;
                else { stableMs = 0; lastSize = sz; }
                if (stableMs >= 1000) break;
            }
        }
        CAPTURE.set(false);
        byte[] pcm;
        synchronized (AUDIO) { pcm = gotFirst ? AUDIO.toByteArray() : null; }
        if (pcm == null || pcm.length < 100) { Log.i(TAG, "no audio captured"); return null; }
        Log.i(TAG, "captured " + pcm.length + "B");
        try { return buildWav(SAMPLE_RATE, pcm); } catch (Throwable t) { return null; }
    }

    // ================== HTTP 桥 ==================
    private static void runServer() {
        try (ServerSocket server = new ServerSocket(PORT, 50, InetAddress.getByName("127.0.0.1"))) {
            Log.i(TAG, "http bridge on " + PORT);
            while (true) {
                Socket s = server.accept();
                try { handle(s); } catch (Throwable t) { try { s.close(); } catch (Throwable ignored) {} }
            }
        } catch (Throwable t) { Log.i(TAG, "server exit " + t); }
    }

    private static void handle(Socket socket) {
        try (Socket auto = socket) {
            socket.setSoTimeout(25000);
            BufferedReader ins = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));
            String line = ins.readLine();
            if (line == null) return;
            String[] parts = line.split(" ");
            String path = parts.length > 1 ? parts[1] : "/";
            String h;
            while ((h = ins.readLine()) != null && !h.isEmpty()) { }
            Log.i(TAG, "req " + path);
            OutputStream out = socket.getOutputStream();
            if (path.startsWith("/health")) {
                write(out, 200, "application/json", "{\"status\":\"ok\",\"voices\":" + VOICE_MAP.size() + "}");
            } else if (path.startsWith("/voices")) {
                JSONArray arr = new JSONArray();
                HashSet<String> seen = new HashSet<>();
                for (JSONObject v : VOICE_MAP.values()) {
                    String k = v.optString("styleId");
                    if (k == null || k.isEmpty() || seen.contains(k)) continue;
                    seen.add(k); arr.put(v);
                }
                write(out, 200, "application/json", arr.toString(2));
            } else if (path.startsWith("/preview?")) {
                Map<String, String> q = queryMap(path);
                JSONObject v = VOICE_MAP.get(q.get("voiceId"));
                String url = v == null ? "" : v.optString("previewUrl");
                if (url != null && !url.isEmpty()) {
                    out.write(("HTTP/1.1 302 Found\r\nLocation: " + url + "\r\n\r\n").getBytes());
                    out.flush(); return;
                }
                write(out, 404, "application/json", "{\"error\":\"no preview\"}");
            } else if (path.startsWith("/play?")) {
                Map<String, String> q = queryMap(path);
                String text = q.getOrDefault("text", "你好");
                String styleId = resolveStyleId(q.getOrDefault("voiceId", ""));
                boolean ok = !styleId.isEmpty() && triggerTts(text, styleId);
                write(out, ok ? 200 : 500, "application/json",
                        ok ? "{\"ok\":true,\"speaking\":true}" : "{\"error\":\"tts failed\"}");
            } else if (path.startsWith("/synthesize?")) {
                Map<String, String> q = queryMap(path);
                String text = q.getOrDefault("text", "你好");
                byte[] wav = doSynthesize(text, q.getOrDefault("voiceId", ""));
                if (wav != null) {
                    out.write("HTTP/1.1 200 OK\r\nContent-Type: audio/wav\r\nContent-Length: ".getBytes());
                    out.write(String.valueOf(wav.length).getBytes());
                    out.write("\r\n\r\n".getBytes());
                    out.write(wav); out.flush(); return;
                }
                write(out, 500, "application/json", "{\"error\":\"synthesize no audio\"}");
            } else if (path.startsWith("/setVoice?")) {
                Map<String, String> q = queryMap(path);
                Object sv = VOICE_OBJ_MAP.get(q.get("voiceId"));
                if (sv != null) {
                    Object mgr = XposedHelpers.getStaticObjectField(MGR_CLS, "a");
                    XposedHelpers.callMethod(mgr, "f", sv);
                    write(out, 200, "application/json", "{\"ok\":true}");
                } else {
                    write(out, 404, "application/json", "{\"error\":\"voice not cached\"}");
                }
            } else if (path.startsWith("/log")) {
                JSONArray arr = new JSONArray();
                for (String s : REQUEST_LOG) arr.put(s);
                write(out, 200, "application/json", arr.toString(2));
            } else {
                write(out, 404, "application/json", "{\"error\":\"not found\"}");
            }
        } catch (Throwable t) { Log.i(TAG, "handle err " + t); }
    }

    private static void write(OutputStream out, int code, String type, String body) throws Exception {
        out.write(("HTTP/1.1 " + code + "\r\nContent-Type: " + type + "\r\n\r\n" + body).getBytes("UTF-8"));
        out.flush();
    }

    private static Map<String, String> queryMap(String path) {
        Map<String, String> m = new HashMap<>();
        try {
            String qs = path.split("\\?")[1];
            for (String kv : qs.split("&")) {
                if (kv == null || kv.isEmpty()) continue;
                String[] p = kv.split("=", 2);
                m.put(p[0], p.length > 1 ? URLDecoder.decode(p[1], "UTF-8") : "");
            }
        } catch (Throwable ignored) {}
        return m;
    }
}
