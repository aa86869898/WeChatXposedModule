package com.yourmod.doubao;

import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/**
 * 微信侧适配器：调用豆包桥合成，返回 WAV 字节。
 * 桥地址 127.0.0.1:58911 与 LSPilot 版一致。
 */
public class WeChatAdapter {

    public static final String BRIDGE = "http://127.0.0.1:58911";

    /** 取音色列表 JSON 字符串（null=桥不可用） */
    public static String doubaoVoices() {
        return httpGetText(BRIDGE + "/voices");
    }

    /** 合成文本 → WAV 字节（null=失败）。voiceId 传 styleId 或 id 均可。 */
    public static byte[] doubaoTts(String text, String voiceId) {
        try {
            String url = BRIDGE + "/synthesize?text=" + URLEncoder.encode(text, "UTF-8")
                    + "&voiceId=" + URLEncoder.encode(voiceId == null ? "" : voiceId, "UTF-8");
            return httpGetBytes(url);
        } catch (Throwable t) {
            Log.i("WeChatAdapter", "doubaoTts err " + t);
            return null;
        }
    }

    /** 触发豆包本地扬声器播报（不拿音频） */
    public static boolean doubaoPlay(String text, String voiceId) {
        try {
            String url = BRIDGE + "/play?text=" + URLEncoder.encode(text, "UTF-8")
                    + "&voiceId=" + URLEncoder.encode(voiceId == null ? "" : voiceId, "UTF-8");
            String r = httpGetText(url);
            return r != null && r.contains("\"ok\"");
        } catch (Throwable t) {
            Log.i("WeChatAdapter", "doubaoPlay err " + t);
            return false;
        }
    }

    // ---------- 基础 HTTP ----------
    private static byte[] httpGetBytes(String urlStr) {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(3000);
            conn.setReadTimeout(20000);
            conn.setRequestMethod("GET");
            InputStream is = conn.getInputStream();
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = is.read(b)) > 0) buf.write(b, 0, n);
            is.close();
            conn.disconnect();
            return buf.toByteArray();
        } catch (Throwable t) {
            Log.i("WeChatAdapter", "httpGet err " + t);
            return null;
        }
    }

    private static String httpGetText(String urlStr) {
        byte[] b = httpGetBytes(urlStr);
        return b == null ? null : new String(b);
    }
}
