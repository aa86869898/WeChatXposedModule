package com.yourmod.doubao;

import android.util.Log;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import de.robv.android.xposed.XposedHelpers;

import io.github.LSPosed.DexKit.ClassData;
import io.github.LSPosed.DexKit.DexKitBridge;
import io.github.LSPosed.DexKit.MethodData;

/**
 * DexKit 动态定位器：豆包升级后硬编码 Hook 失效时的兜底方案。
 * 依赖: implementation 'io.github.LSPosed:DexKit:1.1.8'
 *
 * 用法:
 *   DexLocator.init(lp.appContext.getApplicationInfo().sourceDir);
 *   Class<?> mgr = DexLocator.findClassByStrings(cl, Set.of("TtsClientManager","updateChatBotVoice"));
 *   Method  d   = DexLocator.findMethodInClassByString(mgr, "[TTS] start by message", "d", 12);
 *   XposedBridge.hookMethod(d, callback);
 */
public class DexLocator {
    private static final String TAG = "DexLocator";
    private static volatile String APK_PATH;

    private DexLocator() {}

    /** 必须先在豆包进程调用一次，传入当前 APK 路径 */
    public static void init(String apkPath) {
        APK_PATH = apkPath;
        Log.i(TAG, "DexKit initialized, apk=" + apkPath);
    }

    /** 用字符串指纹定位类；返回 null 表示失败 */
    public static Class<?> findClassByStrings(ClassLoader cl, Set<String> markers) {
        if (APK_PATH == null) return null;
        try (DexKitBridge bridge = DexKitBridge.create(APK_PATH)) {
            Map<String, Set<String>> req = new HashMap<>();
            req.put("target", markers);
            Map<String, List<ClassData>> res = bridge.batchFindClassesUsingStrings(req);
            List<ClassData> list = res.get("target");
            if (list == null || list.isEmpty()) return null;
            ClassData cd = list.get(0);
            String name = cd.getName();          // "Lcom/foo/Bar;"
            if (name.startsWith("L") && name.endsWith(";"))
                name = name.substring(1, name.length() - 1).replace('/', '.');
            Class<?> c = Class.forName(name, false, cl);
            Log.i(TAG, "findClassByStrings -> " + name);
            return c;
        } catch (Throwable t) {
            Log.i(TAG, "findClassByStrings err " + t);
            return null;
        }
    }

    /**
     * 在指定类中，用"方法内字符串"定位方法。
     * @param clazz        目标类
     * @param marker       方法内的特征字符串，如 "[TTS] start by message"
     * @param fallbackName 兜底方法名（DexKit 找不到时按名字找）
     * @param paramCount   期望参数个数（用于过滤重载，-1 忽略）
     */
    public static Method findMethodInClassByString(Class<?> clazz, String marker,
                                                   String fallbackName, int paramCount) {
        if (clazz == null) return null;
        String clsDesc = "L" + clazz.getName().replace('.', '/') + ";";
        // 1) DexKit 按字符串找
        if (APK_PATH != null) {
            try (DexKitBridge bridge = DexKitBridge.create(APK_PATH)) {
                List<MethodData> mds = bridge.findMethodUsingString(marker, true);
                for (MethodData md : mds) {
                    String owner = md.getClassData() == null ? "" : md.getClassData().getName();
                    if (clsDesc.equals(owner)) {
                        Method m = findMethodByName(clazz, md.getName(), paramCount);
                        if (m != null) {
                            Log.i(TAG, "findMethodByString(" + marker + ") -> " + m.getName());
                            return m;
                        }
                    }
                }
            } catch (Throwable t) {
                Log.i(TAG, "findMethodByString err " + t);
            }
        }
        // 2) 兜底：按方法名
        return findMethodByName(clazz, fallbackName, paramCount);
    }

    private static Method findMethodByName(Class<?> clazz, String name, int paramCount) {
        if (name == null) return null;
        for (Method m : clazz.getDeclaredMethods()) {
            if (m.getName().equals(name) && (paramCount < 0 || m.getParameterTypes().length == paramCount)) {
                m.setAccessible(true);
                return m;
            }
        }
        return null;
    }

    /** 便捷：在类里按名字+参数个数找方法（无 DexKit 依赖也能用） */
    public static Method findMethodByName(Class<?> clazz, String name, int paramCount,
                                          Class<?>... paramTypes) {
        if (name == null) return null;
        try {
            Method m = XposedHelpers.findMethodExactIfExists(clazz, name, paramTypes);
            if (m != null) { m.setAccessible(true); return m; }
        } catch (Throwable ignored) {}
        return findMethodByName(clazz, name, paramCount);
    }
}
