package com.yourmod.doubao;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * 内置豆包音色库（100 个）——读取本模块 APK 内置的 assets/voices.json。
 * Xposed 模块里读取"自己的 assets"用 modulePath(即 lpparam.modulePath) 而非宿主 Context。
 *
 * 用法:
 *   DoubaoVoices.getAll(moduleApkPath);            // List<JSONObject>
 *   DoubaoVoices.find(moduleApkPath, styleIdOrId); // 单个
 *   DoubaoVoices.names(moduleApkPath);             // 名字数组
 *
 * 说明: 音色数据来自豆包配置(2026-09 抓取)。豆包在线时可再刷新:
 *       拉 /voices 后手动替换本文件 assets/voices.json 即可。
 */
public final class DoubaoVoices {

    private static final String ASSET = "assets/voices.json";
    private static JSONArray CACHE;

    private DoubaoVoices() {}

    /** 读取全部音色；不可用返回空列表 */
    public static List<JSONObject> getAll(String moduleApkPath) {
        List<JSONObject> out = new ArrayList<>();
        try {
            JSONArray arr = load(moduleApkPath);
            for (int i = 0; i < arr.length(); i++) out.add(arr.getJSONObject(i));
        } catch (Throwable ignored) {}
        return out;
    }

    /** 按 styleId 或 id 查找；找不到返回 null */
    public static JSONObject find(String moduleApkPath, String idOrStyleId) {
        if (idOrStyleId == null) return null;
        try {
            JSONArray arr = load(moduleApkPath);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                if (idOrStyleId.equals(o.optString("styleId"))
                        || idOrStyleId.equals(o.optString("id"))) return o;
            }
        } catch (Throwable ignored) {}
        return null;
    }

    /** 名字数组（用于选择器/日志） */
    public static String[] names(String moduleApkPath) {
        List<JSONObject> all = getAll(moduleApkPath);
        String[] n = new String[all.size()];
        for (int i = 0; i < all.size(); i++) n[i] = all.get(i).optString("name");
        return n;
    }

    private static JSONArray load(String moduleApkPath) throws Exception {
        if (CACHE != null) return CACHE;
        synchronized (DoubaoVoices.class) {
            if (CACHE != null) return CACHE;
            JSONArray arr = null;
            try (ZipFile zip = new ZipFile(moduleApkPath)) {
                ZipEntry e = zip.getEntry(ASSET);
                if (e != null) {
                    InputStream is = zip.getInputStream(e);
                    byte[] buf = readAll(is);
                    is.close();
                    arr = new JSONArray(new String(buf, "UTF-8"));
                }
            }
            if (arr == null) arr = new JSONArray();
            CACHE = arr;
            return arr;
        }
    }

    private static byte[] readAll(InputStream is) throws Exception {
        java.io.ByteArrayOutputStream os = new java.io.ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        while ((n = is.read(b)) > 0) os.write(b, 0, n);
        return os.toByteArray();
    }
}
