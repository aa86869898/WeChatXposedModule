# 豆包音色桥 — 独立Xposed模块源码包

## 架构
一个模块 APK，LSPosed 作用域勾选两个包：
- com.larus.nova (豆包) → DoubaoBridgeCore 跑"桥"（Hook + HTTP服务 127.0.0.1:58911）
- com.tencent.mm (微信) → 你现有模块，用 WeChatAdapter 调桥拿 WAV

## 文件清单
- xposed_init                      Xposed 入口声明（放 assets/ 目录）
- src/HookEntry.java               入口：按包名分流
- src/DoubaoBridgeCore.java        豆包桥核心（Hook音色列表/TTS/音频回调 + HTTP服务）
- src/WeChatAdapter.java           微信侧适配器（HTTP 拿 WAV）
- build_notes.md                   打包说明

## 集成步骤
1. 把 3 个 java 文件放进你的模块工程对应包（如 com.yourmod.doubao）
2. assets/xposed_init 写一行: com.yourmod.doubao.HookEntry
3. build.gradle 依赖: compileOnly 'de.robv.android.xposed:api:82'
4. 装好后 LSPosed 启用模块，作用域勾选: 豆包 + 微信
5. 重启豆包（让它加载桥）；进一次豆包【音色设置】灌满音色
6. 微信侧在你的触发点调用 WeChatAdapter.doubaoTts(text, voiceId)
   拿到 WAV 后转 silk/走你现有发语音流程

## HTTP 接口（与 LSPilot 版一致，微信侧代码通用）
- GET /health                      状态
- GET /voices                      音色列表 JSON
- GET /preview?voiceId=x           试听 302
- GET /play?text=..&voiceId=..     本地扬声器播报
- GET /synthesize?text=..&voiceId=..  返回 WAV 音频
- GET /setVoice?voiceId=..         切换豆包当前音色
- GET /log                         最近合成记录

## 使用注意
- 豆包必须活着（桥在豆包进程内），系统设置里给豆包电池"不限制"
- 音色列表先在豆包【音色设置】翻一遍 tab 才会抓全
- 每个 Hook 独立 try/catch，单点失效不影响 App，看 Logcat 标签 DoubaoBridge

## 升级兼容（见 build_notes.md 第2节）

## v2（新增内置音色库）
- assets/voices.json   ← 100 个豆包音色（id/name/styleId），打包进 APK
- src/DoubaoVoices.java ← 从模块 APK 内置库读取（lpparam.modulePath）
- 微信侧不依赖豆包在线也能展示音色列表；合成仍需豆包桥在线
