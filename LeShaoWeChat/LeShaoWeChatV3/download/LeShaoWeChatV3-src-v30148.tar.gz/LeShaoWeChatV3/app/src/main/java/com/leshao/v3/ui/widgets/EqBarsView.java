package com.leshao.v3.ui.widgets;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.media.MediaPlayer;
import android.media.audiofx.Visualizer;
import android.os.SystemClock;
import android.view.View;
import android.view.animation.LinearInterpolator;

import com.leshao.v3.LogWriter;
import com.leshao.v3.ui.AppColors;

import java.util.Random;

/**
 * v1081 C3 柱状频谱（v1084 提高灵敏度 + 流光渐变）。
 *
 * <p>22 根柱以「流光渐变」着色：三色渐变在整条频谱上横向循环流动。高度由播放器的
 * 实时音频频谱驱动（{@link Visualizer} 挂 {@link MediaPlayer} 的 audio session 取
 * FFT），每根柱按各自频段的长期峰值独立归一，响应更灵敏、大声时明显冲高，且各柱
 * 高低错落，不做左右流动。</p>
 *
 * <p>设备/宿主不支持 {@link Visualizer}（如未授予录音权限）时，自动回退为各柱独立
 * 随机律动，仍保持快节奏升降观感。</p>
 *
 * <p>纯皮肤绘制，不承载业务语义。</p>
 */
public class EqBarsView extends View {

    private static final String TAG = "LeShaoV3.EqBars";
    private static final int BAR_COUNT = 22;
    private static final long FALLBACK_INTERVAL_MS = 80L;
    private static final float MAG_FLOOR = 6f;
    private static final float SILENCE_FLOOR = 2f;
    /** v30018: 柱组（旋律柱）默认占视图宽度 80%，居中，左右各留 10%。 */
    private static final float SPAN_RATIO = 0.80f;
    /** 当前柱组占宽比例，可按页面覆盖（如播放器页 90%）。 */
    private float mSpanRatio = SPAN_RATIO;

    private final Paint mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF mRect = new RectF();
    private final float[] mTarget = new float[BAR_COUNT];
    private final float[] mCurrent = new float[BAR_COUNT];
    private final int[] mPerm = new int[BAR_COUNT];
    private final float[] mBandPeak = new float[BAR_COUNT];
    private final float[] mJitter = new float[BAR_COUNT];
    private final float[] mAttack = new float[BAR_COUNT];
    private final float[] mDecay = new float[BAR_COUNT];
    private final Random mRandom = new Random();

    private ValueAnimator mAnim;
    private Visualizer mVisualizer;
    private boolean mUsingVisualizer;
    private boolean mFallback = true;
    private float mRef = MAG_FLOOR;
    private long mLastFallbackMs;
    private long mLastFftMs;
    private long mLastJitterMs;

    // v1139: 精确模式 —— 由播放线程直接推送 PCM, 本地 FFT 分析, 不依赖 Visualizer
    private static final int PCM_FFT = 1024;
    private final Object mPcmLock = new Object();
    private final float[] mPcmRing = new float[PCM_FFT];
    private int mPcmFill;
    private int mPcmRate = 24000;

    public EqBarsView(Context ctx) {
        super(ctx);
        mPaint.setStyle(Paint.Style.FILL);
        // 固定伪随机：打散「频段→柱」映射并给每根柱不同的起落速度/抖动，
        // 避免所有柱同步升降，也避免相邻柱一起动。
        Random seed = new Random(1081L);
        int[] perm = new int[BAR_COUNT];
        for (int i = 0; i < BAR_COUNT; i++) perm[i] = i;
        for (int i = BAR_COUNT - 1; i > 0; i--) {
            int j = seed.nextInt(i + 1);
            int t = perm[i];
            perm[i] = perm[j];
            perm[j] = t;
        }
        System.arraycopy(perm, 0, mPerm, 0, BAR_COUNT);
        for (int i = 0; i < BAR_COUNT; i++) {
            mJitter[i] = 0.85f + seed.nextFloat() * 0.15f;
            mAttack[i] = 0.50f + seed.nextFloat() * 0.28f;
            mDecay[i] = 0.24f + seed.nextFloat() * 0.20f;
        }
    }

    /** 开始播放态动画（无音频源时使用回退律动）。 */
    public void start() {
        startInternal(null, true);
    }

    /** 开始播放态动画，并尝试绑定播放器音频频谱。 */
    public void start(MediaPlayer player) {
        startInternal(player, true);
    }

    /**
     * v1139: 开始「精确跟随」动画 —— 不做随机回退，柱高完全由
     * {@link #pushPcm(byte[], int, int)} 推送的 PCM 频谱驱动；无数据时保持静止。
     */
    public void startExact() {
        startInternal(null, false);
    }

    private void startInternal(MediaPlayer player, boolean fallback) {
        if (mAnim != null && mAnim.isStarted()) return;
        detachVisualizer();
        mFallback = fallback;
        mUsingVisualizer = false;
        if (fallback && player != null) {
            attachVisualizer(player);
        }
        mLastFallbackMs = 0L;
        mLastFftMs = 0L;
        mLastJitterMs = 0L;
        mRef = MAG_FLOOR;
        for (int i = 0; i < BAR_COUNT; i++) {
            mBandPeak[i] = MAG_FLOOR;
            mTarget[i] = 0f;
            mCurrent[i] = 0f;
        }
        synchronized (mPcmLock) {
            mPcmFill = 0;
        }
        mAnim = ValueAnimator.ofFloat(0f, 1f);
        mAnim.setDuration(1000L);
        mAnim.setRepeatCount(ValueAnimator.INFINITE);
        mAnim.setInterpolator(new LinearInterpolator());
        mAnim.addUpdateListener(a -> onFrame());
        mAnim.start();
    }

    /** 停止动画并回到静止态。 */
    public void stop() {
        detachVisualizer();
        if (mAnim != null) {
            mAnim.cancel();
            mAnim = null;
        }
        for (int i = 0; i < BAR_COUNT; i++) {
            mTarget[i] = 0f;
            mCurrent[i] = 0f;
        }
        invalidate();
    }

    @Override
    protected void onDetachedFromWindow() {
        stop();
        super.onDetachedFromWindow();
    }

    // ==================== 帧驱动：快起快落 ====================

    private void onFrame() {
        long now = SystemClock.uptimeMillis();
        boolean exact = !mFallback && !mUsingVisualizer;
        if (!exact && now - mLastJitterMs >= 130L) {
            mLastJitterMs = now;
            for (int i = 0; i < BAR_COUNT; i++) {
                mJitter[i] = 0.86f + mRandom.nextFloat() * 0.14f;
            }
        }
        if (!mUsingVisualizer) {
            if (mFallback && now - mLastFallbackMs >= FALLBACK_INTERVAL_MS) {
                mLastFallbackMs = now;
                for (int i = 0; i < BAR_COUNT; i++) {
                    mTarget[i] = 0.12f + mRandom.nextFloat() * 0.78f;
                }
            }
        } else if (now - mLastFftMs > 400L) {
            // 频谱回调长时间中断(暂停/异常)时缓慢回落
            mLastFallbackMs = now;
            for (int i = 0; i < BAR_COUNT; i++) {
                mTarget[i] *= 0.5f;
            }
        }
        for (int i = 0; i < BAR_COUNT; i++) {
            float t = mTarget[i] * (exact ? 1f : mJitter[i]);
            if (t > 1f) t = 1f;
            float cur = mCurrent[i];
            float k = t > cur ? mAttack[i] : mDecay[i];
            float next = cur + (t - cur) * k;
            if (Math.abs(next - t) < 0.004f) next = t;
            mCurrent[i] = next;
        }
        invalidate();
    }

    // ==================== 频谱采集 ====================

    private void attachVisualizer(MediaPlayer player) {
        detachVisualizer();
        if (player == null) return;
        try {
            int session = player.getAudioSessionId();
            if (session == 0) return;
            int size = Visualizer.getCaptureSizeRange()[1];
            Visualizer v = new Visualizer(session);
            v.setCaptureSize(size);
            v.setDataCaptureListener(new Visualizer.OnDataCaptureListener() {
                @Override
                public void onWaveFormDataCapture(Visualizer visualizer, byte[] waveform, int rate) {
                }

                @Override
                public void onFftDataCapture(Visualizer visualizer, byte[] fft, int rate) {
                    applyFft(fft, rate);
                }
            }, Visualizer.getMaxCaptureRate(), false, true);
            v.setEnabled(true);
            mVisualizer = v;
            mUsingVisualizer = true;
            LogWriter.log(TAG, "Visualizer 已绑定 session=" + session + " size=" + size);
        } catch (Throwable t) {
            mUsingVisualizer = false;
            mVisualizer = null;
            LogWriter.log(TAG, "Visualizer 不可用, 回退模拟律动: " + t);
        }
    }

    private void detachVisualizer() {
        if (mVisualizer != null) {
            try {
                mVisualizer.setEnabled(false);
            } catch (Throwable ignored) {
            }
            try {
                mVisualizer.release();
            } catch (Throwable ignored) {
            }
            mVisualizer = null;
        }
        mUsingVisualizer = false;
    }

    /**
     * 将 Visualizer FFT 帧映射到 22 根柱的目标高度。
     *
     * <p>每个频段维护各自的长期峰值（快起慢落）并独立归一，因此大声时对应柱会明显
     * 冲高，各柱互不牵连；再用整体响度做动态门限，安静时整体压低，避免动辄顶到最上端。</p>
     */
    private void applyFft(byte[] fft, int samplingRate) {
        if (fft == null || fft.length < 4) return;
        mLastFftMs = SystemClock.uptimeMillis();
        int capture = fft.length;
        int bins = capture / 2;
        int sr = samplingRate > 0 ? samplingRate : 44100;

        float[] mags = new float[BAR_COUNT];
        for (int b = 0; b < BAR_COUNT; b++) {
            int ks = bandFreq(b, capture, sr, bins);
            int ke = Math.max(ks + 1, bandFreq(b + 1, capture, sr, bins));
            float sum = 0f;
            int n = 0;
            for (int k = ks; k < ke && k < bins; k++) {
                float re = fft[2 * k];
                float im = fft[2 * k + 1];
                sum += (float) Math.sqrt(re * re + im * im);
                n++;
            }
            mags[b] = n > 0 ? sum / n : 0f;
        }
        updateTargets(mags);
    }

    /**
     * 把 22 个频段能量映射为柱目标高度：每柱独立峰值归一（快起慢落）+ 整体响度门限。
     * Visualizer FFT 与本地 PCM FFT 共用此逻辑，保证两条链路观感一致。
     */
    private void updateTargets(float[] mags) {
        float frameSum = 0f;
        for (int i = 0; i < BAR_COUNT; i++) frameSum += mags[i];
        float frameMean = frameSum / BAR_COUNT;

        for (int i = 0; i < BAR_COUNT; i++) {
            int band = mPerm[i];
            float mag = mags[band];
            // 每根柱独立峰值：瞬时上去，慢慢回落，保证大声时明显冲高
            float peak = mBandPeak[band] = Math.max(mag, mBandPeak[band] * 0.9975f);
            float denom = Math.max(peak, MAG_FLOOR);
            float v;
            if (mag < SILENCE_FLOOR) {
                v = 0f;
            } else {
                v = mag / denom;
                // gamma<1 扩张中低幅度，小声音也有明显起伏
                v = (float) Math.pow(v, 0.78) * 1.05f;
            }
            if (v < 0f) v = 0f;
            else if (v > 1f) v = 1f;
            mTarget[i] = v;
        }

        // 整体响度门限：长期均值慢释放，安静段落整体压低
        mRef = Math.max(frameMean, mRef * 0.9993f);
        if (mRef < MAG_FLOOR) mRef = MAG_FLOOR;
        float loud = frameMean / mRef;
        if (loud < 0f) loud = 0f;
        else if (loud > 1f) loud = 1f;
        float gate = 0.55f + 0.45f * loud;
        for (int i = 0; i < BAR_COUNT; i++) {
            mTarget[i] *= gate;
        }
    }

    private int bandFreq(int band, int capture, int samplingRate, int bins) {
        return bandFreq(band, capture, samplingRate, bins, 16000.0);
    }

    private int bandFreq(int band, int capture, int samplingRate, int bins, double fMax) {
        double fMin = 60.0;
        // 不超过 Nyquist 的 98%, 避免采样率受限时高频段全部挤到最后一个 bin
        double nyq = samplingRate / 2.0 * 0.98;
        if (fMax > nyq) fMax = nyq;
        double f = fMin * Math.pow(fMax / fMin, band / (double) BAR_COUNT);
        int k = (int) (f * capture / (double) samplingRate);
        return Math.max(1, Math.min(bins - 1, k));
    }

    /** v1139: 设置精确模式 PCM 采样率（默认 24kHz）。 */
    public void setPcmSampleRate(int rate) {
        if (rate > 0) mPcmRate = rate;
    }

    /** 设置柱组（旋律柱）占视图宽度的比例，取值 (0, 1]，默认 80%。 */
    public void setSpanRatio(float ratio) {
        if (ratio > 0f && ratio <= 1f) {
            mSpanRatio = ratio;
            invalidate();
        }
    }

    /**
     * v1139: 精确模式数据入口 —— 播放线程把 16bit LE mono PCM 块推入，
     * 内部对最近 {@link #PCM_FFT} 个样本做 Hann 窗 FFT 并更新 22 柱目标高度，
     * 从而让柱体精准跟随音乐的低/中/高频与节奏。由播放线程调用，内部加锁。
     */
    public void pushPcm(byte[] pcm, int offset, int len) {
        if (pcm == null || len < 2) return;
        if (mAnim == null || !mAnim.isStarted()) return;
        synchronized (mPcmLock) {
            int end = Math.min(pcm.length, offset + len);
            for (int i = offset; i + 1 < end; i += 2) {
                int lo = pcm[i] & 0xFF;
                int hi = pcm[i + 1];
                mPcmRing[mPcmFill] = (short) ((hi << 8) | lo);
                mPcmFill = (mPcmFill + 1) % PCM_FFT;
            }
            analyzePcmLocked();
        }
    }

    private void analyzePcmLocked() {
        float[] re = new float[PCM_FFT];
        float[] im = new float[PCM_FFT];
        for (int i = 0; i < PCM_FFT; i++) {
            float s = mPcmRing[(mPcmFill + i) % PCM_FFT] / 32768f;
            re[i] = s * (float) (0.5 - 0.5 * Math.cos(2.0 * Math.PI * i / (PCM_FFT - 1)));
        }
        fft(re, im, PCM_FFT);
        int bins = PCM_FFT / 2;
        float[] mags = new float[BAR_COUNT];
        for (int b = 0; b < BAR_COUNT; b++) {
            int ks = bandFreq(b, PCM_FFT, mPcmRate, bins, 16000.0);
            int ke = Math.max(ks + 1, bandFreq(b + 1, PCM_FFT, mPcmRate, bins, 16000.0));
            float sum = 0f;
            int n = 0;
            for (int k = ks; k < ke && k < bins; k++) {
                sum += (float) Math.sqrt(re[k] * re[k] + im[k] * im[k]);
                n++;
            }
            mags[b] = n > 0 ? sum / n : 0f;
        }
        updateTargets(mags);
    }

    /** 原地 radix-2 复数 FFT（n 为 2 的幂）。 */
    private static void fft(float[] re, float[] im, int n) {
        for (int i = 1, j = 0; i < n; i++) {
            int bit = n >> 1;
            for (; (j & bit) != 0; bit >>= 1) j ^= bit;
            j ^= bit;
            if (i < j) {
                float t = re[i]; re[i] = re[j]; re[j] = t;
                t = im[i]; im[i] = im[j]; im[j] = t;
            }
        }
        for (int len = 2; len <= n; len <<= 1) {
            int half = len >> 1;
            double ang = -2.0 * Math.PI / len;
            float wr = (float) Math.cos(ang), wi = (float) Math.sin(ang);
            for (int i = 0; i < n; i += len) {
                float cwr = 1f, cwi = 0f;
                for (int k = 0; k < half; k++) {
                    float ur = re[i + k], ui = im[i + k];
                    float vr = re[i + k + half] * cwr - im[i + k + half] * cwi;
                    float vi = re[i + k + half] * cwi + im[i + k + half] * cwr;
                    re[i + k] = ur + vr; im[i + k] = ui + vi;
                    re[i + k + half] = ur - vr; im[i + k + half] = ui - vi;
                    float nwr = cwr * wr - cwi * wi;
                    cwi = cwr * wi + cwi * wr;
                    cwr = nwr;
                }
            }
        }
    }

    // ==================== 绘制 ====================

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        mPaint.setShader(null);
    }

    private void ensureGradient(int w) {
        mPaint.setShader(null);
        mPaint.setColor(AppColors.primary());
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        float d = getResources().getDisplayMetrics().density;
        float gap = 3f * d;
        // 旋律柱占视图宽度指定比例并居中
        float span = w * mSpanRatio;
        float spanLeft = (w - span) / 2f;
        float barW = (span - gap * (BAR_COUNT - 1)) / BAR_COUNT;
        if (barW <= 0f) return;
        float radius = Math.min(barW, 4f * d);

        // 纯色填充：跟随模块主题主色
        ensureGradient(w);

        for (int i = 0; i < BAR_COUNT; i++) {
            float v = mCurrent[i];
            if (v < 0f) v = 0f;
            else if (v > 1f) v = 1f;
            float bh = h * (0.06f + 0.94f * v);
            float left = spanLeft + i * (barW + gap);
            mRect.set(left, h - bh, left + barW, h);
            canvas.drawRoundRect(mRect, radius, radius, mPaint);
        }
    }
}
