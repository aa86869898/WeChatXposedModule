package com.leshao.v3.ui;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.View;
import android.widget.Switch;

/**
 * LeShaoWeChat 组件工厂 —— Material 3 规范。
 * 公开方法签名与旧版完全一致（全项目调用点零改动），内部实现切换为 M3：
 *  - 开关 52×32dp 轨道 + 16/24dp thumb 双态（M3 Switch 规范）
 *  - 卡片 filled/elevated 双型，12dp 圆角
 *  - 对话框 28dp extra-large 圆角
 *  - 按压涟漪用 M3 状态层（12% onSurface）
 */
public class CandyUi {

    private static int dp(Context ctx, float v) {
        return (int) (v * ctx.getResources().getDisplayMetrics().density + 0.5f);
    }

    /**
     * M3 开关：轨道 52×32dp（开=深蓝/关=灰），thumb 外圈圆环包裹本体。
     *
     * <p>v1056 关键修复：改用 framework {@link android.widget.Switch}。此前用
     * {@code SwitchMaterial}（appcompat）时，其构造会读取 appcompat 属性 ID，而模块资源未注入
     * 宿主(微信)资源表，属性 ID 与宿主资源碰撞 → 解析到 {@code res/raw/chatfrom_voice_playing_f3.svg}
     * 并抛 {@code Resources$NotFoundException}，导致所有开关创建失败、个性化配置面板整体构建中断。</p>
     */
    @SuppressWarnings("deprecation")
    public static Switch newSwitch(Context ctx) {
        Switch sw = new Switch(ctx);
        float d = ctx.getResources().getDisplayMetrics().density;
        int w = (int) (AppColors.SWITCH_WIDTH_DP * d);
        int h = (int) (AppColors.SWITCH_HEIGHT_DP * d);
        int trackR = (int) (AppColors.SWITCH_RADIUS_DP * d);
        int thumbOff = (int) (20 * d);
        int thumbOn = (int) (26 * d);
        sw.setMinimumWidth(w);
        sw.setMinimumHeight(h);
        sw.setPadding(0, 0, 0, 0);
        sw.setTextOff("");
        sw.setTextOn("");
        sw.setShowText(false);
        try {
            // 自绘 track/thumb 精确保留原配色与尺寸；清空框架 tint 避免覆盖自定义绘制(API 21+)。
            if (android.os.Build.VERSION.SDK_INT >= 21) {
                sw.setTrackTintList(null);
                sw.setThumbTintList(null);
            }
            // v967 关键修复: 自定义 track/thumb 为 GradientDrawable 时无 intrinsic size,
            // 必须对每个 drawable 调用 setSize() 显式提供 intrinsic 尺寸。
            StateListDrawable track = new StateListDrawable();
            GradientDrawable off = new GradientDrawable();
            off.setShape(GradientDrawable.RECTANGLE);
            off.setCornerRadius(trackR);
            off.setColor(AppColors.surfaceContainerHighest());
            off.setStroke(dp(ctx, 2), AppColors.outline());
            off.setSize(w, h);
            track.addState(new int[]{-android.R.attr.state_checked}, off);
            // 打开状态轨道：纯色 primary 填充，圆角胶囊形。
            GradientDrawable on = new GradientDrawable();
            on.setColor(AppColors.primary());
            on.setCornerRadius(trackR);
            on.setSize(w, h);
            track.addState(new int[]{android.R.attr.state_checked}, on);
            sw.setTrackDrawable(track);

            // thumb：白色圆形 + 底部浅阴影，开/关状态一致。
            StateListDrawable thumb = new StateListDrawable();
            thumb.addState(new int[]{-android.R.attr.state_checked}, whiteThumb(ctx, thumbOff));
            thumb.addState(new int[]{android.R.attr.state_checked}, whiteThumb(ctx, thumbOn));
            sw.setThumbDrawable(thumb);

            sw.setBackground(null);
            sw.setSwitchMinWidth(w);
        } catch (Throwable ignored) {}
        return sw;
    }

    /**
     * 白色圆形 thumb：底部叠加 1dp 半透明阴影层，形成浅投影。
     * 仅使用 framework drawable，兼容微信宿主进程（无 Material 依赖）。
     */
    private static Drawable whiteThumb(Context ctx, int sizePx) {
        int shadow = Math.max(1, dp(ctx, 1));
        GradientDrawable shadowLayer = new GradientDrawable();
        shadowLayer.setShape(GradientDrawable.OVAL);
        shadowLayer.setColor(0x33000000);
        shadowLayer.setSize(sizePx, sizePx);

        GradientDrawable body = new GradientDrawable();
        body.setShape(GradientDrawable.OVAL);
        body.setColor(0xFFFFFFFF);
        int inner = Math.max(sizePx - shadow * 2, 1);
        body.setSize(inner, inner);

        LayerDrawable ld = new LayerDrawable(new Drawable[]{shadowLayer, body});
        ld.setLayerInset(1, shadow, 0, shadow, shadow * 2);
        return ld;
    }

    /**
     * 页面根背景：M3 surface 纯色 + 28dp 圆角浮层。
     *
     * <p>v987 统一透明化：全屏页面统一改为圆角浮层，圆角外区域由透明窗口露出宿主，
     * 不再用直角实底填满整屏（避免在状态栏/安全区露出白色实底间隔）。</p>
     */
    public static GradientDrawable pageGradient() {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        float d = Resources.getSystem().getDisplayMetrics().density;
        gd.setCornerRadius(AppColors.DIALOG_RADIUS_DP * d);
        // 去渐变：页面浮层统一纯色 surfaceContainerLowest 底
        gd.setColor(AppColors.surfaceContainerLowest());
        gd.setStroke(Math.max(1, (int) (1.0f * d + 0.5f)), AppColors.outlineVariant());
        return gd;
    }

/** v3.0.101：糖果粉纯色圆角底（保留动画接口），用于按钮/徽标/FAB 等主色面 */
    public static Drawable gradientBg(Context ctx, float radiusDp) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(dp(ctx, radiusDp));
        gd.setColor(AppColors.primary());
        return gd;
    }

    /** v3.0.101：糖果粉纯色圆角底，用于按钮/徽标/卡片等主色面 */
    public static Drawable gradientBgStatic(Context ctx, float radiusDp) {
        return gradientBg(ctx, radiusDp);
    }

    /** v3.0.101：顶栏/Hero 糖果粉纯色底——仅上方圆角，贴合页面浮层顶部 */
    public static Drawable topBarGradientBg(Context ctx) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        float r = AppColors.DIALOG_RADIUS_DP * ctx.getResources().getDisplayMetrics().density;
        gd.setCornerRadii(new float[]{r, r, r, r, 0f, 0f, 0f, 0f});
        gd.setColor(AppColors.primary());
        return gd;
    }

    /**
     * v998: 给浮层容器附加轻微阴影(硬件层 elevation)，与 {@link #pageGradient()} 的描边配合，
     * 让居中浮层与宿主画面之间产生柔和层次。
     */
    public static void elevate(View v) {
        if (v == null) return;
        try {
            float d = v.getResources().getDisplayMetrics().density;
            v.setElevation(12f * d);
            if (android.os.Build.VERSION.SDK_INT >= 21) {
                v.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);
            }
        } catch (Throwable ignored) {
        }
    }

    /** M3 Expressive filled 卡片：surfaceContainerLowest（浅色纯白）底 + 24dp 大圆角 */
    public static GradientDrawable cardBg(Context ctx) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(dp(ctx, AppColors.SHAPE_CARD_DP));
        gd.setColor(AppColors.surfaceContainerLowest());
        if (AppColors.isDarkMode()) {
            gd.setStroke(dp(ctx, 0.5f), AppColors.outlineVariant());
        }
        return gd;
    }

    /** M3 Expressive elevated 卡片：surfaceContainerLowest 底 + 24dp 大圆角 + 细描边（暗色下区分层级） */
    public static GradientDrawable cardElevatedBg(Context ctx) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(dp(ctx, AppColors.SHAPE_CARD_DP));
        gd.setColor(AppColors.surfaceContainerLowest());
        if (AppColors.isDarkMode()) {
            gd.setStroke(dp(ctx, 0.5f), AppColors.outlineVariant());
        }
        return gd;
    }

    /** M3 Expressive 行背景：surfaceContainerLow 底 + 16dp 圆角（独立行/列表行） */
    public static GradientDrawable rowBg(Context ctx) {
        return roundedRect(AppColors.surfaceContainerLow(), dp(ctx, AppColors.SHAPE_LG_DP));
    }

    /** M3 Expressive 指定圆角卡片底（供页面自定义卡片半径时使用） */
    public static GradientDrawable cardBgRadius(Context ctx, float radiusDp) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(dp(ctx, radiusDp));
        gd.setColor(AppColors.surfaceContainerLowest());
        if (AppColors.isDarkMode()) {
            gd.setStroke(dp(ctx, 0.5f), AppColors.outlineVariant());
        }
        return gd;
    }

    /** M3 Expressive filter chip：药丸全圆角，选中主色纯色 / 未选中 surfaceContainerLow + outline 描边 */
    public static Drawable pillBg(boolean selected, Context ctx) {
        if (selected) {
            GradientDrawable gd = new GradientDrawable();
            gd.setShape(GradientDrawable.RECTANGLE);
            gd.setCornerRadius(dp(ctx, AppColors.SHAPE_FULL_DP));
            gd.setColor(AppColors.primary());
            return gd;
        }
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(dp(ctx, AppColors.SHAPE_FULL_DP));
        gd.setColor(AppColors.surfaceContainerLow());
        gd.setStroke(dp(ctx, 1), AppColors.outline());
        return gd;
    }

    /** M3 标签底：primaryContainer 底 + 8dp 圆角 */
    public static GradientDrawable tagPinkBg(Context ctx) {
        return roundedRect(AppColors.primaryContainer(), dp(ctx, AppColors.SHAPE_SM_DP));
    }

    /** M3 标签底：tertiaryContainer 底 + 8dp 圆角 */
    public static GradientDrawable tagYellowBg(Context ctx) {
        return roundedRect(AppColors.tertiaryContainer(), dp(ctx, AppColors.SHAPE_SM_DP));
    }

    /** M3 filled text field：surfaceContainerHighest 底 + 16dp 圆角 + outline 描边 */
    public static GradientDrawable inputBg(Context ctx) {
        GradientDrawable gd = roundedRect(AppColors.surfaceContainerHighest(), dp(ctx, AppColors.SHAPE_INPUT_DP));
        gd.setStroke(dp(ctx, 1), AppColors.outlineVariant());
        return gd;
    }

    /** M3 filled button：糖果粉纯色底 + 全圆角 + 状态层涟漪（v3.0.101） */
    public static Drawable buttonBg(Context ctx) {
        StateListDrawable sd = new StateListDrawable();
        GradientDrawable pressed = new GradientDrawable();
        pressed.setShape(GradientDrawable.RECTANGLE);
        pressed.setCornerRadius(dp(ctx, AppColors.SHAPE_FULL_DP));
        pressed.setColor(AppColors.gradientPressed());
        GradientDrawable normal = new GradientDrawable();
        normal.setShape(GradientDrawable.RECTANGLE);
        normal.setCornerRadius(dp(ctx, AppColors.SHAPE_FULL_DP));
        normal.setColor(AppColors.primary());
        sd.addState(new int[]{android.R.attr.state_pressed}, pressed);
        sd.addState(new int[]{}, normal);
        return rippleWrap(ctx, sd, AppColors.stateLayerOnPrimary());
    }

    /** M3 outlined button：透明底 + outline 描边 + 全圆角 + 状态层涟漪 */
    public static Drawable buttonGhostBg(Context ctx) {
        StateListDrawable sd = new StateListDrawable();
        GradientDrawable pressed = new GradientDrawable();
        pressed.setShape(GradientDrawable.RECTANGLE);
        pressed.setCornerRadius(dp(ctx, AppColors.SHAPE_FULL_DP));
        pressed.setColor(AppColors.stateLayerPressed());
        GradientDrawable normal = new GradientDrawable();
        normal.setShape(GradientDrawable.RECTANGLE);
        normal.setCornerRadius(dp(ctx, AppColors.SHAPE_FULL_DP));
        normal.setColor(0x00000000);
        normal.setStroke(dp(ctx, 1), AppColors.outline());
        sd.addState(new int[]{android.R.attr.state_pressed}, pressed);
        sd.addState(new int[]{}, normal);
        return rippleWrap(ctx, sd, AppColors.stateLayerPressed());
    }

    /** M3 filled tonal button（危险）：error 底 + 全圆角 + 状态层涟漪 */
    public static Drawable buttonDangerBg(Context ctx) {
        StateListDrawable sd = new StateListDrawable();
        GradientDrawable pressed = new GradientDrawable();
        pressed.setShape(GradientDrawable.RECTANGLE);
        pressed.setCornerRadius(dp(ctx, AppColors.SHAPE_FULL_DP));
        pressed.setColor(0xFF8C0F16);
        GradientDrawable normal = new GradientDrawable();
        normal.setShape(GradientDrawable.RECTANGLE);
        normal.setCornerRadius(dp(ctx, AppColors.SHAPE_FULL_DP));
        normal.setColor(AppColors.error());
        sd.addState(new int[]{android.R.attr.state_pressed}, pressed);
        sd.addState(new int[]{}, normal);
        return rippleWrap(ctx, sd, 0x1FFFFFFF);
    }

    /** M3 text button：透明底 + 全圆角涟漪 */
    public static Drawable buttonTextBg(Context ctx) {
        GradientDrawable normal = new GradientDrawable();
        normal.setShape(GradientDrawable.RECTANGLE);
        normal.setCornerRadius(dp(ctx, AppColors.SHAPE_FULL_DP));
        normal.setColor(0x00000000);
        return rippleWrap(ctx, normal, AppColors.stateLayerPressed());
    }

    /** 为任意已 setClickable 的 View 附加 M3 状态层涟漪 foreground（全圆角边界）。 */
    public static void ripple(View v, float radiusDp) {
        if (v == null) return;
        try {
            float d = v.getResources().getDisplayMetrics().density;
            GradientDrawable mask = new GradientDrawable();
            mask.setShape(GradientDrawable.RECTANGLE);
            mask.setCornerRadius(radiusDp * d);
            mask.setColor(0xFFFFFFFF);
            v.setForeground(new RippleDrawable(
                    android.content.res.ColorStateList.valueOf(AppColors.stateLayerPressed()), null, mask));
        } catch (Throwable ignored) {}
    }

    /** 将 StateListDrawable 包成 M3 涟漪(显式全圆角遮罩, 保证透明底按钮也有边界涟漪) */
    private static Drawable rippleWrap(Context ctx, Drawable content, int rippleColor) {
        try {
            GradientDrawable mask = new GradientDrawable();
            mask.setShape(GradientDrawable.RECTANGLE);
            mask.setCornerRadius(dp(ctx, AppColors.SHAPE_FULL_DP));
            mask.setColor(0xFFFFFFFF);
            return new RippleDrawable(
                    android.content.res.ColorStateList.valueOf(rippleColor), content, mask);
        } catch (Throwable t) {
            return content;
        }
    }

    /** M3 行按压状态层：12% onSurface 涟漪 + 16dp 圆角裁剪 */
    public static Drawable rowPressBg(Context ctx) {
        try {
            GradientDrawable mask = new GradientDrawable();
            mask.setShape(GradientDrawable.RECTANGLE);
            mask.setCornerRadius(dp(ctx, AppColors.SHAPE_LG_DP));
            mask.setColor(AppColors.surfaceContainerLow());
            return new RippleDrawable(
                android.content.res.ColorStateList.valueOf(AppColors.stateLayerPressed()),
                null, mask);
        } catch (Throwable t) {
            GradientDrawable gd = new GradientDrawable();
            gd.setShape(GradientDrawable.RECTANGLE);
            gd.setCornerRadius(dp(ctx, AppColors.SHAPE_LG_DP));
            gd.setColor(AppColors.stateLayerPressed());
            return gd;
        }
    }

    /** v1142: 按当前浮层层级自动区分底色的对话框背景（叠加时更易分辨）。 */
    public static GradientDrawable dialogBg(Context ctx) {
        return dialogBg(ctx, WindowLayer.depth());
    }

    /**
     * M3 对话框：底色随层级变化 + （第 2 层起）1dp 描边。
     * <ul>
     *   <li>第 1 层：surfaceContainerHigh（保持原有观感）</li>
     *   <li>第 2 层：surfaceContainerHighest</li>
     *   <li>第 3 层起：向 primaryContainer 逐层混色（上限 24%），越上层越突出</li>
     * </ul>
     */
    public static GradientDrawable dialogBg(Context ctx, int layer) {
        int color;
        if (layer <= 0) {
            color = AppColors.surfaceContainerHigh();
        } else if (layer == 1) {
            color = AppColors.surfaceContainerHighest();
        } else {
            float t = Math.min(0.06f * layer, 0.24f);
            color = blend(AppColors.surfaceContainerHighest(), AppColors.primaryContainer(), t);
        }
        GradientDrawable gd = roundedRect(color, dp(ctx, AppColors.DIALOG_RADIUS_DP));
        if (layer > 0) {
            gd.setStroke(dp(ctx, 1), AppColors.outlineVariant());
        }
        return gd;
    }

    /** v1142: 两色线性混色（0=全 c1，1=全 c2）。 */
    public static int blend(int c1, int c2, float t) {
        if (t < 0f) t = 0f;
        if (t > 1f) t = 1f;
        int a1 = (c1 >>> 24) & 0xFF, r1 = (c1 >> 16) & 0xFF, g1 = (c1 >> 8) & 0xFF, b1 = c1 & 0xFF;
        int a2 = (c2 >>> 24) & 0xFF, r2 = (c2 >> 16) & 0xFF, g2 = (c2 >> 8) & 0xFF, b2 = c2 & 0xFF;
        int a = (int) (a1 + (a2 - a1) * t);
        int r = (int) (r1 + (r2 - r1) * t);
        int g = (int) (g1 + (g2 - g1) * t);
        int b = (int) (b1 + (b2 - b1) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static GradientDrawable roundedRect(int color, int radius) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(radius);
        gd.setColor(color);
        return gd;
    }

    private CandyUi() {}
}
