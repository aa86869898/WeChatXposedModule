package com.leshao.v3.hook;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.NinePatch;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.NinePatchDrawable;

import com.leshao.v3.LogWriter;

/**
 * 自定义气泡 Drawable 工厂（ChatBubbleHook 的辅助类）。
 *
 * <p>文本气泡承载视图是 {@code com.tencent.mm.ui.widget.MMNeat7extView}，其背景需可随内容拉伸。
 * 任意位图无法在 Java 层安全构造 native 9-patch chunk（device 格式含指针字段），因此：</p>
 * <ul>
 *   <li>若用户选择的是真正的 *.9.png，交给框架 {@link BitmapFactory} 解码，可得 device 格式的
 *       nine-patch chunk，走 {@link NinePatchDrawable}，保留原始拉伸与内容边距语义；</li>
 *   <li>否则使用自实现的 {@link NineSliceDrawable}，按四角固定、四边与中心拉伸的 9-slice 规则
 *       绘制，得到与 9-patch 等价的拉伸效果，且完全规避 native chunk 构造风险。</li>
 * </ul>
 */
final class BubbleDrawableFactory {

    private BubbleDrawableFactory() {}

    static Drawable build(Context ctx, String path) {
        if (ctx == null || path == null || path.isEmpty()) return null;
        Resources res = ctx.getResources();

        // v3.0.141：不再只认 ".9.png" 后缀。微信把用户气泡存为 bubble_*.png 时可能已去掉
        // ".9" 后缀，但文件内容仍是编译后的 nine-patch（PNG 内嵌 tEXt chunk）。
        // 因此统一先尝试框架解码：若 Bitmap 携带有效 chunk，得到精确拉伸区 + 内容边距。
        Drawable np = buildFromNinePatchFile(res, path);
        if (np != null) return np;

        Bitmap bmp = decode(path);
        if (bmp == null) return null;

        // v3.0.142b：用户上传的 .9.png 若未经 aapt 编译（无 tEXt chunk），BitmapFactory
        // 不会生成 NinePatch chunk —— 但图片四边仍带有黑线标记。此时从边缘像素检测
        // 拉伸区，按原始拉伸区构建 NineSliceDrawable，不再全局按短边 1/6 拉伸。
        int[] slices = detectNinePatchSlices(bmp);
        if (slices != null) {
            LogWriter.log("Bubble", "ninepatch marks detected sliceX=" + slices[0]
                    + " sliceY=" + slices[1] + " size=" + bmp.getWidth() + "x" + bmp.getHeight());
            return new NineSliceDrawable(res, bmp, slices[0], slices[1]);
        }
        return new NineSliceDrawable(res, bmp, Math.max(1, Math.min(bmp.getWidth(), bmp.getHeight()) / 6));
    }

    /** 用框架解码 *.9.png 得到真正的 NinePatchDrawable；失败返回 null。 */
    private static Drawable buildFromNinePatchFile(Resources res, String path) {
        try {
            Bitmap bmp = BitmapFactory.decodeFile(path);
            if (bmp == null) return null;
            byte[] chunk = bmp.getNinePatchChunk();
            if (chunk == null || !NinePatch.isNinePatchChunk(chunk)) {
                bmp.recycle();
                return null;
            }
            NinePatch np = new NinePatch(bmp, chunk, null);
            return new NinePatchDrawable(res, np);
        } catch (Throwable t) {
            LogWriter.log("Bubble", "ninepatch file decode err: " + t.getMessage());
            return null;
        }
    }

    private static Bitmap decode(String path) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, bounds);
            int maxEdge = 1024;
            int sample = 1;
            while (sample > 0 && (bounds.outWidth / sample > maxEdge || bounds.outHeight / sample > maxEdge)) {
                sample *= 2;
            }
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = sample;
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap bmp = BitmapFactory.decodeFile(path, o);
            if (bmp == null) return null;
            if (bmp.getConfig() != Bitmap.Config.ARGB_8888) {
                Bitmap converted = bmp.copy(Bitmap.Config.ARGB_8888, false);
                if (converted != null) {
                    bmp.recycle();
                    return converted;
                }
            }
            return bmp;
        } catch (Throwable t) {
            LogWriter.log("Bubble", "decode failed: " + t.getMessage());
            return null;
        }
    }

    /**
     * 从位图四边检测 .9.png 黑线标记（未编译的 nine-patch 源图）。
     * 顶部黑线起点 = 水平拉伸区左边界（即左侧固定区宽度 sliceX）；
     * 左侧黑线起点 = 垂直拉伸区上边界（即顶部固定区高度 sliceY）。
     * 仅当顶部与左侧都存在有效黑线且未贯通整边时返回 {sliceX, sliceY}，否则返回 null。
     */
    private static int[] detectNinePatchSlices(Bitmap bmp) {
        if (bmp == null) return null;
        int w = bmp.getWidth();
        int h = bmp.getHeight();
        if (w < 3 || h < 3) return null;
        try {
            int[] top = new int[w];
            bmp.getPixels(top, 0, w, 0, 0, w, 1);
            int[] left = new int[h];
            bmp.getPixels(left, 0, 1, 0, 0, 1, h);

            int xStart = -1;
            int xEnd = -1;
            for (int x = 0; x < w; x++) {
                if (isNinePatchMark(top[x])) {
                    if (xStart < 0) xStart = x;
                    xEnd = x;
                }
            }
            int yStart = -1;
            int yEnd = -1;
            for (int y = 0; y < h; y++) {
                if (isNinePatchMark(left[y])) {
                    if (yStart < 0) yStart = y;
                    yEnd = y;
                }
            }
            // 黑线必须存在、不接触左右/上下端点（否则没有固定角区）
            if (xStart <= 0 || yStart <= 0) return null;
            if (xEnd >= w - 1 || yEnd >= h - 1) return null;
            // 黑线不能横跨整条边（至少留 1px 角区）
            if (xEnd - xStart + 1 >= w - 2) return null;
            if (yEnd - yStart + 1 >= h - 2) return null;
            return new int[]{xStart, yStart};
        } catch (Throwable t) {
            return null;
        }
    }

    /** .9.png 标记像素：高不透明度的近黑色像素（黑线可能被微信重编码，放宽阈值）。 */
    private static boolean isNinePatchMark(int pixel) {
        int a = (pixel >>> 24) & 0xFF;
        if (a < 0x80) return false;
        int r = (pixel >> 16) & 0xFF;
        int g = (pixel >> 8) & 0xFF;
        int b = pixel & 0xFF;
        return r < 0x60 && g < 0x60 && b < 0x60;
    }

    /**
     * 自实现 9-slice Drawable：把源位图按“四角 1:1、四边单轴拉伸、中心双轴拉伸”绘制到目标区域。
     *
     * <p>slice 尺寸取图片短边的 1/6（至少 1px），对常见圆角气泡可正确保留圆角而拉伸中间。
     * 纯 Java 绘制，不涉及 native nine-patch chunk，无崩溃风险。
     * v3.0.142b：支持水平/垂直不同 slice（sliceX/sliceY），用于未编译 .9.png 黑线拉伸区。</p>
     */
    static final class NineSliceDrawable extends Drawable {
        private final Bitmap src;
        private final int sliceX;
        private final int sliceY;
        private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
        private final Rect dst = new Rect();

        NineSliceDrawable(Resources res, Bitmap src, int slice) {
            this(res, src, slice, slice);
        }

        NineSliceDrawable(Resources res, Bitmap src, int sliceX, int sliceY) {
            this.src = src;
            int maxX = Math.max(1, src.getWidth() / 2);
            int maxY = Math.max(1, src.getHeight() / 2);
            this.sliceX = Math.max(1, Math.min(sliceX, maxX));
            this.sliceY = Math.max(1, Math.min(sliceY, maxY));
            this.paint.setAntiAlias(true);
            this.paint.setFilterBitmap(true);
        }

        @Override
        public void draw(Canvas canvas) {
            Rect b = getBounds();
            if (b.isEmpty() || src.isRecycled()) return;
            int w = src.getWidth();
            int h = src.getHeight();
            int sx = sliceX;
            int sy = sliceY;
            if (w <= 2 * sx || h <= 2 * sy) {
                canvas.drawBitmap(src, null, b, paint);
                return;
            }
            int[] xs = {0, sx, w - sx, w};
            int[] ys = {0, sy, h - sy, h};
            int[] dx = {b.left, b.left + sx, b.right - sx, b.right};
            int[] dy = {b.top, b.top + sy, b.bottom - sy, b.bottom};
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    if (i == 1 && j == 1) continue; // 中心单独处理
                    src(dx[i], dy[j], dx[i + 1], dy[j + 1],
                            xs[i], ys[j], xs[i + 1], ys[j + 1], canvas);
                }
            }
            // 中心区域：双向拉伸
            src(dx[1], dy[1], dx[2], dy[2], xs[1], ys[1], xs[2], ys[2], canvas);
        }

        private void src(int dl, int dt, int dr, int db,
                         int sl, int st, int sr, int sb, Canvas canvas) {
            if (dr <= dl || db <= dt || sr <= sl || sb <= st) return;
            dst.set(dl, dt, dr, db);
            Rect sRect = new Rect(sl, st, sr, sb);
            canvas.drawBitmap(src, sRect, dst, paint);
        }

        @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); invalidateSelf(); }
        @Override public void setColorFilter(android.graphics.ColorFilter cf) { paint.setColorFilter(cf); invalidateSelf(); }
        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
        @Override public int getIntrinsicWidth() { return src.getWidth(); }
        @Override public int getIntrinsicHeight() { return src.getHeight(); }

        /** v3.0.141：提供内容边距。微信原生气泡 NinePatchDrawable 自带 padding 指定文字
         *  内容区；此前 NineSliceDrawable 未实现 getPadding → 替换后文字贴边/错位。
         *  这里用 slice（=圆角固定区尺寸）作为内容边距，文字自动缩进到圆角内部。
         *  v3.0.142b：sliceX/sliceY 分离后，左右边距=sliceX、上下边距=sliceY。 */
        @Override public boolean getPadding(Rect padding) {
            if (padding == null) return true;
            padding.set(sliceX, sliceY, sliceX, sliceY);
            return true;
        }

        @Override public Drawable.ConstantState getConstantState() {
            return new ConstantState() {
                @Override public Drawable newDrawable() { return new NineSliceDrawable(null, src, sliceX, sliceY); }
                @Override public Drawable newDrawable(Resources res) { return new NineSliceDrawable(res, src, sliceX, sliceY); }
                @Override public int getChangingConfigurations() { return 0; }
            };
        }
    }
}
